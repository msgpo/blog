for i in [1, 2, 3, 4]:
    print "The count is", i
    print "Done counting"
