def f(x):
    return x + 4

print f(1) * f(0) * f(-1)
