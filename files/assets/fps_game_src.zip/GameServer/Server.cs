using System;
using Microsoft.DirectX;
using Microsoft.DirectX.DirectPlay;

namespace GameServer
{
	/// <summary>
	/// Summary description for DirectPlayServer.
	/// </summary>
	public class DirectPlayServer
	{
		public static readonly System.Guid ApplicationGuid = new Guid("{DCC56EE8-0265-4e9b-91E8-A1210B12E0AC}");
		public static readonly int Port = 2782;

		//DirectPlay variables
		protected Server DPServer = null;
		protected Address LocalAddress = new Address();
		protected bool IsConnected = false;

		public DirectPlayServer()
		{
			InitializeServer();
		}

		public void Host(String SessionName)
		{
			LocalAddress.AddComponent("port", Port);

			ApplicationDescription AppDesc = new ApplicationDescription();
			AppDesc.GuidApplication = ApplicationGuid;
			AppDesc.SessionName = SessionName;
			AppDesc.Flags = SessionFlags.ClientServer | SessionFlags.NoDpnServer;

			DPServer.Host(AppDesc, LocalAddress);
			IsConnected = true;
		}

		public void Disconnect()
		{
			//Disconnect and reconnect
			IsConnected = false;
			InitializeServer();
		}

		public void SendPacket(NetworkPacket Packet)
		{
			//Broadcast
			DPServer.SendTo( (int)PlayerID.AllPlayers, Packet, 0, 
				SendFlags.Sync | SendFlags.NoLoopback );
		}

		private void InitializeServer()
		{
			//Dispose if necessary
			if (DPServer != null)
			{
				DPServer.Dispose();
			}

			DPServer = new Server();

			//Attach events
			DPServer.Receive += new ReceiveEventHandler(DPServer_Receive);
			DPServer.PlayerCreated += new PlayerCreatedEventHandler(DPServer_PlayerCreated);
			DPServer.PlayerDestroyed += new PlayerDestroyedEventHandler(DPServer_PlayerDestroyed);

			//Set as local provider
			LocalAddress.ServiceProvider = Address.ServiceProviderTcpIp;
		}

		private void DPServer_Receive(object sender, ReceiveEventArgs e)
		{
			//Send string for processing
			ProcessPacket(e.Message);
		}

		public virtual void ProcessPacket(ReceiveMessage Message)
		{
			//Do nothing
		}

		private void DPServer_PlayerCreated(object sender, PlayerCreatedEventArgs e)
		{
			PlayerJoined(e.Message);
		}

		private void DPServer_PlayerDestroyed(object sender, PlayerDestroyedEventArgs e)
		{
			PlayerLeft(e.Message);
		}

		public virtual void PlayerJoined(CreatePlayerMessage Message)
		{
			//Do nothing
		}

		public virtual void PlayerLeft(DestroyPlayerMessage Message)
		{
			//Do nothing
		}
	}
}
