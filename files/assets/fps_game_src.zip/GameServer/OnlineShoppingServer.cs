using System;

//DirectX
using Microsoft.DirectX;

//DirectPlay
using Microsoft.DirectX.DirectPlay;
using DirectPlay = Microsoft.DirectX.DirectPlay;

namespace GameServer
{
	/// <summary>
	/// Summary description for OnlineShoppingServer.
	/// </summary>

	public enum MessageType
	{
		AnnounceUser, RemoveUser, ChatMessage
	}

	public class OnlineShoppingServer : DirectPlayServer
	{
		public OnlineShoppingServer()
		{
			//
			// TODO: Add constructor logic here
			//
		}
		
		public override void ProcessPacket(DirectPlay.ReceiveMessage Message)
		{
			MessageType MType = (MessageType)Message.ReceiveData.Read( typeof(MessageType) );

			switch(MType)
			{
				case MessageType.AnnounceUser:
					break;

				case MessageType.RemoveUser:
					break;

				case MessageType.ChatMessage:
					break;
			}
		}

		public override void PlayerJoined(CreatePlayerMessage Message)
		{
			
		}

		public override void PlayerLeft(DestroyPlayerMessage Message)
		{
			
		}
	}
}
