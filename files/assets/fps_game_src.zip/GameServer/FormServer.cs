using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.IO;
using System.Xml;
using System.Runtime.InteropServices;

//DirectX
using Microsoft.DirectX;

//DirectPlay
using Microsoft.DirectX.DirectPlay;
using Voice = Microsoft.DirectX.DirectPlay.Voice;
using DirectPlay = Microsoft.DirectX.DirectPlay;

//Vector3
using WanderEngine;
using Vector3 = WanderEngine.Vector3;

//DirectSound
using Microsoft.DirectX.DirectSound;

namespace GameServer
{
	/// <summary>
	/// Summary description for FormServer.
	/// </summary>
	
	public enum MessageType
	{
		AddPlayer, RemovePlayer, AddCurrentPlayer, UpdateState, PrivateMessage, ChatMessage,
		Hurt, Kill, ServerTime, GameOver, Respawn, ItemInfo, ItemState, MarkPlayer, UnmarkPlayer,
		RoundInfo, LaserBeam
	}

	public enum PlayMode
	{
		Deathmatch, ItemGrab, MarkedMan
	}

	public enum ItemType
	{
		Health, Special, Ammo
	}

	public class FormServer : System.Windows.Forms.Form
	{
		private System.Windows.Forms.RichTextBox RichTextBoxConsole;
		private System.Windows.Forms.NumericUpDown NumericUpDownMinutes;
		private System.Windows.Forms.Label LabelMinutes;
		private System.Windows.Forms.Button ButtonStart;
		private System.Windows.Forms.ComboBox ComboBoxMode;
		private System.Windows.Forms.Label LabelTime;
		private System.Windows.Forms.Timer TimerMain;
		private System.Windows.Forms.Panel PanelTop;
		private System.ComponentModel.IContainer components;

		#region Imported Functions

		[DllImport("user32", CharSet=CharSet.Auto)]
		public static extern bool GetScrollRange(IntPtr hWnd, int nBar, out int lpMinPos, out int lpMaxPos);

		[DllImport("user32", CharSet=CharSet.Auto)]
		public static extern IntPtr SendMessage(IntPtr hWnd, int msg, int wParam, POINT lParam);

		[StructLayout(LayoutKind.Sequential)]
			public class POINT
		{
			public int X;
			public int Y;

			public POINT()
			{
			}

			public POINT(int X, int Y)
			{
				this.X = X;
				this.Y = Y;
			}
		}

		//Constants
		public const int SB_VERT = 1;
		public const int EM_SETSCROLLPOS = 0x0400 + 222;

		#endregion

		private delegate void StringDelegate(String S);

		//Server variables
		public static readonly System.Guid ApplicationGuid = new Guid("{DCC56EE8-0265-4e9b-91E8-A1210B12E0AC}");
		public static readonly int Port = 12548;

		//FPS variables
		private int SecondsLeft = 0;
		private PlayMode CurrentMode = PlayMode.Deathmatch;
		private Hashtable PlayerScore = new Hashtable();
		private ArrayList Points = new ArrayList();
		private Hashtable ItemActive = new Hashtable();
		private Hashtable RespawnTimes = new Hashtable();
		private double[] RandomNumbers = null;
		private int MarkedID = -1;

		//DirectPlay variables
		private Server DPServer = null;
		private Address LocalAddress = new Address();
		private bool IsConnected = false;

		private Voice.Server ServerVoice = null;
				
		public FormServer()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			ComboBoxMode.SelectedIndex = 0;
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(FormServer));
			this.RichTextBoxConsole = new System.Windows.Forms.RichTextBox();
			this.PanelTop = new System.Windows.Forms.Panel();
			this.LabelTime = new System.Windows.Forms.Label();
			this.ButtonStart = new System.Windows.Forms.Button();
			this.LabelMinutes = new System.Windows.Forms.Label();
			this.NumericUpDownMinutes = new System.Windows.Forms.NumericUpDown();
			this.ComboBoxMode = new System.Windows.Forms.ComboBox();
			this.TimerMain = new System.Windows.Forms.Timer(this.components);
			this.PanelTop.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.NumericUpDownMinutes)).BeginInit();
			this.SuspendLayout();
			// 
			// RichTextBoxConsole
			// 
			this.RichTextBoxConsole.BackColor = System.Drawing.Color.Black;
			this.RichTextBoxConsole.Dock = System.Windows.Forms.DockStyle.Fill;
			this.RichTextBoxConsole.ForeColor = System.Drawing.Color.White;
			this.RichTextBoxConsole.Location = new System.Drawing.Point(0, 48);
			this.RichTextBoxConsole.Name = "RichTextBoxConsole";
			this.RichTextBoxConsole.ReadOnly = true;
			this.RichTextBoxConsole.Size = new System.Drawing.Size(488, 293);
			this.RichTextBoxConsole.TabIndex = 0;
			this.RichTextBoxConsole.TabStop = false;
			this.RichTextBoxConsole.Text = "";
			// 
			// PanelTop
			// 
			this.PanelTop.Controls.Add(this.LabelTime);
			this.PanelTop.Controls.Add(this.ButtonStart);
			this.PanelTop.Controls.Add(this.LabelMinutes);
			this.PanelTop.Controls.Add(this.NumericUpDownMinutes);
			this.PanelTop.Controls.Add(this.ComboBoxMode);
			this.PanelTop.Dock = System.Windows.Forms.DockStyle.Top;
			this.PanelTop.Location = new System.Drawing.Point(0, 0);
			this.PanelTop.Name = "PanelTop";
			this.PanelTop.Size = new System.Drawing.Size(488, 48);
			this.PanelTop.TabIndex = 1;
			// 
			// LabelTime
			// 
			this.LabelTime.Font = new System.Drawing.Font("Monotype Corsiva", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.LabelTime.ForeColor = System.Drawing.Color.MidnightBlue;
			this.LabelTime.Location = new System.Drawing.Point(352, 9);
			this.LabelTime.Name = "LabelTime";
			this.LabelTime.Size = new System.Drawing.Size(128, 23);
			this.LabelTime.TabIndex = 4;
			this.LabelTime.Text = "0:00 left";
			this.LabelTime.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// ButtonStart
			// 
			this.ButtonStart.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.ButtonStart.Location = new System.Drawing.Point(264, 8);
			this.ButtonStart.Name = "ButtonStart";
			this.ButtonStart.Size = new System.Drawing.Size(80, 23);
			this.ButtonStart.TabIndex = 3;
			this.ButtonStart.Text = "&Start";
			this.ButtonStart.Click += new System.EventHandler(this.ButtonStart_Click);
			// 
			// LabelMinutes
			// 
			this.LabelMinutes.Location = new System.Drawing.Point(208, 8);
			this.LabelMinutes.Name = "LabelMinutes";
			this.LabelMinutes.Size = new System.Drawing.Size(56, 23);
			this.LabelMinutes.TabIndex = 2;
			this.LabelMinutes.Text = "minutes";
			this.LabelMinutes.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// NumericUpDownMinutes
			// 
			this.NumericUpDownMinutes.Location = new System.Drawing.Point(144, 8);
			this.NumericUpDownMinutes.Maximum = new System.Decimal(new int[] {
																				 120,
																				 0,
																				 0,
																				 0});
			this.NumericUpDownMinutes.Minimum = new System.Decimal(new int[] {
																				 1,
																				 0,
																				 0,
																				 0});
			this.NumericUpDownMinutes.Name = "NumericUpDownMinutes";
			this.NumericUpDownMinutes.Size = new System.Drawing.Size(64, 20);
			this.NumericUpDownMinutes.TabIndex = 1;
			this.NumericUpDownMinutes.Value = new System.Decimal(new int[] {
																			   10,
																			   0,
																			   0,
																			   0});
			// 
			// ComboBoxMode
			// 
			this.ComboBoxMode.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.ComboBoxMode.Items.AddRange(new object[] {
															  "Deathmatch",
															  "Item Grab",
															  "Marked Man"});
			this.ComboBoxMode.Location = new System.Drawing.Point(8, 8);
			this.ComboBoxMode.Name = "ComboBoxMode";
			this.ComboBoxMode.Size = new System.Drawing.Size(120, 21);
			this.ComboBoxMode.TabIndex = 0;
			// 
			// TimerMain
			// 
			this.TimerMain.Enabled = true;
			this.TimerMain.Interval = 1000;
			this.TimerMain.Tick += new System.EventHandler(this.TimerMain_Tick);
			// 
			// FormServer
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(488, 341);
			this.Controls.Add(this.RichTextBoxConsole);
			this.Controls.Add(this.PanelTop);
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.Name = "FormServer";
			this.Text = "Game Server";
			this.Closing += new System.ComponentModel.CancelEventHandler(this.FormServer_Closing);
			this.Load += new System.EventHandler(this.FormServer_Load);
			this.Paint += new System.Windows.Forms.PaintEventHandler(this.FormServer_Paint);
			this.PanelTop.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this.NumericUpDownMinutes)).EndInit();
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			//Enable XP themes
			Application.EnableVisualStyles();
			Application.DoEvents();

			Application.Run(new FormServer());
		}

		public void Host(String SessionName)
		{
			LocalAddress.AddComponent("port", Port);

			ApplicationDescription AppDesc = new ApplicationDescription();
			AppDesc.GuidApplication = ApplicationGuid;
			AppDesc.SessionName = SessionName;
			AppDesc.Flags = SessionFlags.ClientServer | SessionFlags.NoDpnServer;

			DPServer.Host(AppDesc, LocalAddress);
			IsConnected = true;

			/*
			//Create voice server
			ServerVoice = new Voice.Server(DPServer);
			Voice.SessionDescription Desc = new Voice.SessionDescription();
			Desc.SessionType = Voice.SessionType.Mixing;
			Desc.BufferQuality = Voice.BufferQuality.Default;
			Desc.GuidCompressionType = Voice.CompressionGuid.Default;
			Desc.BufferAggressiveness = Voice.BufferAggressiveness.Default;

			//Start voice session
			ServerVoice.StartSession(Desc);
			*/
		}

		public void Disconnect()
		{
			//Disconnect
			IsConnected = false;

			if (DPServer != null)
			{
				//DPServer.Dispose();
				DPServer = null;
			}

			if (ServerVoice != null)
			{
				ServerVoice.Dispose();
				ServerVoice = null;
			}
		}

		private void InitializeServer()
		{
			//Dispose if necessary
			if (DPServer != null)
			{
				DPServer.Dispose();
			}

			DPServer = new Server();

			//Hook events
			DPServer.Receive += new ReceiveEventHandler(DPServer_Receive);
			
			//Set as local provider
			LocalAddress.ServiceProvider = Address.ServiceProviderTcpIp;			
		}

		private void DPServer_Receive(object sender, ReceiveEventArgs e)
		{
			try
			{
				NetworkPacket Packet = e.Message.ReceiveData;
				MessageType MsgType = (MessageType)Packet.Read(typeof(MessageType));

				//State variables
				int CurrentID = -1;
				String CurrentName = "";
				NetworkPacket SendPacket;
				float X = 0.0f, Y = 0.0f, Z = 0.0f, Yaw = 0.0f;

				switch(MsgType)
				{
					case MessageType.AddPlayer:
						CurrentID = (int)Packet.Read(typeof(int));
						CurrentName = Packet.ReadString();

						//Add to score table
						lock(PlayerScore)
						{
							PlayerScore[CurrentID] = 0;
						}

						//Write to console
						WriteConsole(CurrentName + " has joined the session");

						//Broadcast to everyone
						DPServer.SendTo((int)PlayerID.AllPlayers, Packet, 0, SendFlags.Guaranteed | SendFlags.NoLoopback);

						//Send round info
						String RoundInfo = "";

						switch(CurrentMode)
						{
							case PlayMode.Deathmatch:
								RoundInfo = "Kill as many players as possible to win!";
								break;

							case PlayMode.ItemGrab:
								RoundInfo = "Grab as many items as you can to win!";
								break;

							case PlayMode.MarkedMan:
								RoundInfo = "Kill the marked man and survive to win!";
								break;
						}

						SendPacket = new NetworkPacket();
						SendPacket.Write(MessageType.RoundInfo);
						SendPacket.Write(RoundInfo);

						//Send
						DPServer.SendTo(CurrentID, SendPacket, 0, SendFlags.Guaranteed | SendFlags.NoLoopback);

						//Mark if necessary
						if ( (CurrentMode == PlayMode.MarkedMan) && (MarkedID == -1) )
						{
							SetMarkedPlayer(CurrentID);
						}

						//Send item info
						WriteConsole("Sending item information to " + CurrentName);

						ItemType IType = ItemType.Health;

						switch(CurrentMode)
						{
							case PlayMode.Deathmatch:
							case PlayMode.MarkedMan:
								IType = ItemType.Health;
								break;

							case PlayMode.ItemGrab:
								IType = ItemType.Special;
								break;
						}

						for (int i=0; i<Points.Count; i++)
						{
							Vector3 Point = (Vector3)Points[i];

							SendPacket = new NetworkPacket();
							SendPacket.Write(MessageType.ItemInfo);
							SendPacket.Write(i);

							if (RandomNumbers[i] > 0.35)
							{
								SendPacket.Write(IType);
							}
							else
							{
								SendPacket.Write(ItemType.Ammo);
							}

							SendPacket.Write(Point.X);
							SendPacket.Write(Point.Y);
							SendPacket.Write(Point.Z);
							
							bool Active = false;

							if (ItemActive.Contains(i))
							{
								Active = (bool)ItemActive[i];
							}

							SendPacket.Write(Active);

							//Send
							DPServer.SendTo(CurrentID, SendPacket, 0, SendFlags.Guaranteed | SendFlags.NoLoopback);
						}
						
						break;

					case MessageType.AddCurrentPlayer:
						CurrentID = (int)Packet.Read(typeof(int));
						CurrentName = Packet.ReadString();
						String ModelName = Packet.ReadString();
						X = (float)Packet.Read(typeof(float));
						Y = (float)Packet.Read(typeof(float));
						Z = (float)Packet.Read(typeof(float));
						Yaw = (float)Packet.Read(typeof(float));
						bool IsMarked = (bool)Packet.Read(typeof(bool));

						//Write to console
						WriteConsole("Sending add current player request for " + CurrentName);

						//Repackage
						SendPacket = new NetworkPacket();
						SendPacket.Write(MessageType.AddCurrentPlayer);
						SendPacket.Write(e.Message.SenderID);
						SendPacket.Write(CurrentName);
						SendPacket.Write(ModelName);
						SendPacket.Write(X);
						SendPacket.Write(Y);
						SendPacket.Write(Z);
						SendPacket.Write(Yaw);
						SendPacket.Write(IsMarked);

						//Send to reciever
						DPServer.SendTo(CurrentID, SendPacket, 0, SendFlags.Guaranteed | SendFlags.NoLoopback);
						break;
				
					case MessageType.PrivateMessage:
					case MessageType.ChatMessage:
						CurrentID = (int)Packet.Read(typeof(int));
						String Message = Packet.ReadString();

						//Write to console
						WriteConsole( DPServer.GetClientInformation(e.Message.SenderID).Name +
							": " + Message );

						//Repackage
						SendPacket = new NetworkPacket();
						SendPacket.Write(MsgType);
						SendPacket.Write(e.Message.SenderID);
						SendPacket.Write(Message);

						//Send to reciever
						DPServer.SendTo(CurrentID, SendPacket, 0, SendFlags.Guaranteed | SendFlags.NoLoopback);
						break;

					case MessageType.UpdateState:
						CurrentID = (int)Packet.Read(typeof(int));

						X = (float)Packet.Read(typeof(float));
						Y = (float)Packet.Read(typeof(float));
						Z = (float)Packet.Read(typeof(float));
						Yaw = (float)Packet.Read(typeof(float));

						//Repackage
						SendPacket = new NetworkPacket();
						SendPacket.Write(MessageType.UpdateState);
						SendPacket.Write(CurrentID);
						SendPacket.Write(X);
						SendPacket.Write(Y);
						SendPacket.Write(Z);
						SendPacket.Write(Yaw);

						//Broadcast to everyone
						DPServer.SendTo((int)PlayerID.AllPlayers, Packet, 0, SendFlags.Guaranteed | SendFlags.NoLoopback);
						break;

					case MessageType.RemovePlayer:
						CurrentID = (int)Packet.Read(typeof(int));
						CurrentName = Packet.ReadString();

						//Broadcast to everyone
						DPServer.SendTo((int)PlayerID.AllPlayers, Packet, 0, SendFlags.Guaranteed | SendFlags.NoLoopback);

						//Write to console
						WriteConsole( CurrentName + " left the session");
						break;

					case MessageType.Hurt:
						int AttackerID = (int)Packet.Read(typeof(int));
						CurrentID = (int)Packet.Read(typeof(int));
						float Damage = (float)Packet.Read(typeof(float));
						float DamageX = (float)Packet.Read(typeof(float));
						float DamageY = (float)Packet.Read(typeof(float));
						float DamageZ = (float)Packet.Read(typeof(float));

						SendPacket = new NetworkPacket();
						SendPacket.Write(MessageType.Hurt);
						SendPacket.Write(AttackerID);
						SendPacket.Write(Damage);
						SendPacket.Write(DamageX);
						SendPacket.Write(DamageY);
						SendPacket.Write(DamageZ);

						//Send to reciever
						DPServer.SendTo(CurrentID, SendPacket, 0, SendFlags.Guaranteed | SendFlags.NoLoopback);
						break;

					case MessageType.Respawn:
						CurrentID = (int)Packet.Read(typeof(int));

						SendPacket = new NetworkPacket();
						SendPacket.Write(MessageType.Respawn);
						SendPacket.Write(CurrentID);

						//Broadcast to everyone
						DPServer.SendTo((int)PlayerID.AllPlayers, SendPacket, 0, SendFlags.Guaranteed | SendFlags.NoLoopback);
						break;

					case MessageType.Kill:
						CurrentID = (int)Packet.Read(typeof(int));
						int KillerID = (int)Packet.Read(typeof(int));

						SendPacket = new NetworkPacket();
						SendPacket.Write(MessageType.Kill);
						SendPacket.Write(CurrentID);
						SendPacket.Write(KillerID);

						//Record score
						if (CurrentID != KillerID)
						{
							lock(PlayerScore)
							{
								if (PlayerScore.Contains(KillerID))
								{
									int Score = (int)PlayerScore[KillerID];
									Score++;
									PlayerScore[KillerID] = Score;
								}
							}

							//Broadcast to everyone
							DPServer.SendTo((int)PlayerID.AllPlayers, SendPacket, 0, SendFlags.Guaranteed | SendFlags.NoLoopback);

							//Mark if necessary
							if (CurrentMode == PlayMode.MarkedMan)
							{
								if (CurrentID == MarkedID)
								{
									SetMarkedPlayer(KillerID);
								}
							}
						}
						else
						{
							if (CurrentMode == PlayMode.MarkedMan)
							{
								if (CurrentID == MarkedID)
								{
									foreach(int NewID in PlayerScore.Keys)
									{
										if (NewID != CurrentID)
										{
											SetMarkedPlayer(NewID);
										}
									}
								}
							}
						}

						WriteConsole( GetPlayerName(KillerID) + " killed " + GetPlayerName(CurrentID) );
						break;

					case MessageType.ItemState:
						CurrentID = (int)Packet.Read(typeof(int));
						int ItemID = (int)Packet.Read(typeof(int));
						bool ItemState = (bool)Packet.Read(typeof(bool));

						if (CurrentMode == PlayMode.ItemGrab)
						{
							if (PlayerScore.Contains(CurrentID))
							{
								int Score = (int)PlayerScore[CurrentID];
								Score++;
								PlayerScore[CurrentID] = Score;
							}
						}

						if (ItemActive.Contains(ItemID))
						{
							ItemActive[ItemID] = ItemState;
						}

						SendPacket = new NetworkPacket();
						SendPacket.Write(MessageType.ItemState);
						SendPacket.Write(ItemID);
						SendPacket.Write(ItemState);

						//Broadcast to everyone
						DPServer.SendTo((int)PlayerID.AllPlayers, SendPacket, 0, SendFlags.Guaranteed | SendFlags.NoLoopback);
						break;

					case MessageType.LaserBeam:
						//Broadcast to everyone
						DPServer.SendTo((int)PlayerID.AllPlayers, Packet, 0, SendFlags.Guaranteed | SendFlags.NoLoopback);
						break;
				}
			}
			catch(Exception ex)
			{
				WriteConsole("Error: " + ex.Message);
			}
		}

		private String GetPlayerName(int ID)
		{
			String Name = "";
			
			try
			{
				Name = DPServer.GetClientInformation(ID).Name;
			}
			catch
			{
				//Do nothing
			}
			
			return(Name);
		}

		private void SetMarkedPlayer(int ID)
		{
			if (MarkedID != -1)
			{
				//Unmark
				NetworkPacket UnmarkPacket = new NetworkPacket();
				UnmarkPacket.Write(MessageType.UnmarkPlayer);
				UnmarkPacket.Write(MarkedID);

				//Broadcast to everyone
				DPServer.SendTo((int)PlayerID.AllPlayers, UnmarkPacket, 0, SendFlags.Guaranteed | SendFlags.NoLoopback);
			}

			//Mark
			MarkedID = ID;
			
			NetworkPacket MarkPacket = new NetworkPacket();
			MarkPacket.Write(MessageType.MarkPlayer);
			MarkPacket.Write(MarkedID);

			//Broadcast to everyone
			DPServer.SendTo((int)PlayerID.AllPlayers, MarkPacket, 0, SendFlags.Guaranteed | SendFlags.NoLoopback);
		}

		private void WriteConsole(String Message)
		{
			RichTextBoxConsole.Invoke( new StringDelegate(WriteConsole_Safe), 
				new object[] { Message } );
		}

		private void WriteConsole_Safe(String Message)
		{
			RichTextBoxConsole.AppendText(DateTime.Now.ToLongTimeString() + " ");
			RichTextBoxConsole.AppendText(Message);
			RichTextBoxConsole.AppendText("\n");

			//Scroll to the bottom
			int MinScroll, MaxScroll;
			GetScrollRange(RichTextBoxConsole.Handle, SB_VERT, out MinScroll, out MaxScroll);
			SendMessage(RichTextBoxConsole.Handle, EM_SETSCROLLPOS, 0, new POINT(0, MaxScroll - RichTextBoxConsole.Height)); 
		}

		private void FormServer_Closing(object sender, System.ComponentModel.CancelEventArgs e)
		{
			Disconnect();
			WriteConsole("Disconnected");
		}

		private void FormServer_Paint(object sender, System.Windows.Forms.PaintEventArgs e)
		{
			RichTextBoxConsole.Refresh();
		}

		private void ButtonStart_Click(object sender, System.EventArgs e)
		{
			try
			{
				//Set mode
				switch(ComboBoxMode.SelectedItem.ToString())
				{
					case "Deathmatch":
						CurrentMode = PlayMode.Deathmatch;
						break;

					case "Item Grab":
						CurrentMode = PlayMode.ItemGrab;
						break;

					case "Marked Man":
						CurrentMode = PlayMode.MarkedMan;
						break;
				}

				InitializeServer();
				Host("Final");
				WriteConsole("Hosting session");

				//Setup timer
				SecondsLeft = (int)NumericUpDownMinutes.Value * 60;

				//Setup controls
				ComboBoxMode.Enabled = false;
				NumericUpDownMinutes.Enabled = false;
				ButtonStart.Enabled = false;
				LabelMinutes.Enabled = false;
			}
			catch(Exception ex)
			{
				MessageBox.Show(ex.Message);
			}
		}

		private void TimerMain_Tick(object sender, System.EventArgs e)
		{
			if (IsConnected)
			{
				//Update items
				for (int i=0; i<Points.Count; i++)
				{
					if (ItemActive.Contains(i))
					{
						bool Active = (bool)ItemActive[i];

						//Respawn if necessary
						if (!Active)
						{
							if (RespawnTimes.Contains(i))
							{
								float Time = (float)RespawnTimes[i];

								Time -= 1.0f;

								if (Time <= 0.0f)
								{
									ItemActive[i] = true;
									RespawnTimes[i] = 15.0f;

									NetworkPacket Packet = new NetworkPacket();
									Packet.Write(MessageType.ItemState);
									Packet.Write(i);
									Packet.Write(true);

									//Broadcast to everyone
									DPServer.SendTo((int)PlayerID.AllPlayers, Packet, 0, SendFlags.Guaranteed | SendFlags.NoLoopback);
								}
								else
								{
									RespawnTimes[i] = Time;
								}
							}
						}
					}
				}

				//Update game state
				SecondsLeft--;
				TimeSpan TimeLeft = new TimeSpan(0, 0, 0, SecondsLeft);
				LabelTime.Text = TimeLeft.ToString() + " left";
				LabelTime.Refresh();
				
				if (SecondsLeft > 0)
				{
					NetworkPacket SendPacket = new NetworkPacket();
					SendPacket.Write(MessageType.ServerTime);
					SendPacket.Write(SecondsLeft);

					//Broadcast to everyone
					DPServer.SendTo((int)PlayerID.AllPlayers, SendPacket, 0, SendFlags.Guaranteed | SendFlags.NoLoopback);
				}
				else
				{
					//Decide a winner
					lock(PlayerScore)
					{
						int MaxID = -1;
						int MaxScore = int.MinValue;

						if (CurrentMode == PlayMode.MarkedMan)
						{
							if (MarkedID != -1)
							{
								MaxID = MarkedID;
								MaxScore = (int)PlayerScore[MarkedID];
							}
						}
						else
						{
							foreach(int ID in PlayerScore.Keys)
							{
								int Score = (int)PlayerScore[ID];

								if (Score > MaxScore)
								{
									MaxID = ID;
									MaxScore = Score;
								}
							}
						}

						String WinnerName = GetPlayerName(MaxID);
						WriteConsole( WinnerName + " won with a score of " + MaxScore.ToString() );

						//Send game over message
						NetworkPacket SendPacket = new NetworkPacket();
						SendPacket.Write(MessageType.GameOver);
						SendPacket.Write(MaxID);
						SendPacket.Write(WinnerName);
						SendPacket.Write(MaxScore);

						//Broadcast to everyone
						DPServer.SendTo((int)PlayerID.AllPlayers, SendPacket, 0, SendFlags.Guaranteed | SendFlags.NoLoopback);

						//Restart session
						WriteConsole("Session restarted");
						SecondsLeft = (int)NumericUpDownMinutes.Value * 60;

						Hashtable TempScores = new Hashtable();
						foreach(int ID in PlayerScore.Keys)
						{
							TempScores[ID] = 0;
						}

						PlayerScore = TempScores;
					}
				}
			}
				
		}

		private void FormServer_Load(object sender, System.EventArgs e)
		{
			XmlTextReader Reader = new XmlTextReader( new FileStream(Application.StartupPath + @"\points.xml", FileMode.Open) );

			Vector3 Point = null;

			while(Reader.Read())
			{
				switch(Reader.NodeType)
				{
					case XmlNodeType.Element:
                        
					switch(Reader.Name)
					{
						case "point":
							Point = new Vector3();
							break;

						case "x":
							Point.X = float.Parse( Reader.ReadString() );
							break;

						case "y":
							Point.Y = float.Parse( Reader.ReadString() );
							break;

						case "z":
							Point.Z = float.Parse( Reader.ReadString() );
							break;
					}

						break;

					case XmlNodeType.EndElement:

						if (Reader.Name == "point")
						{
							int Index = Points.Add(Point);
							ItemActive[Index] = true;
							RespawnTimes[Index] = 15.0f;
						}

						break;
				}
			}

			Reader.Close();

			//Generate numbers
			Random Generator = new Random();
			RandomNumbers = new double[Points.Count];
			for (int i=0; i<Points.Count; i++)
			{
				RandomNumbers[i] = Generator.NextDouble();
			}
		}
	}
}
