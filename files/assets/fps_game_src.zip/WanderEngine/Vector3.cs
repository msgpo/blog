using System;

namespace WanderEngine
{
	/// <summary>
	/// Summary description for Vector3.
	/// </summary>
	public class Vector3
	{
		public float X = 0.0f, Y = 0.0f, Z = 0.0f;

		public Vector3()
		{
			//Do nothing
		}

		public Vector3(float X, float Y, float Z)
		{
			//Copy values
			this.X = X;
			this.Y = Y;
			this.Z = Z;
		}

		public static Vector3 operator+(Vector3 A, Vector3 B)
		{
			return( new Vector3(A.X + B.X, A.Y + B.Y, A.Z + B.Z) );
		}

		public static Vector3 operator-(Vector3 A, Vector3 B)
		{
			return( new Vector3(A.X - B.X, A.Y - B.Y, A.Z - B.Z) );
		}

		public static Vector3 operator*(Vector3 A, Vector3 B)
		{
			return( new Vector3(A.X * B.X, A.Y * B.Y, A.Z * B.Z) );
		}

		public static Vector3 operator/(Vector3 A, Vector3 B)
		{
			return( new Vector3(A.X / B.X, A.Y / B.Y, A.Z / B.Z) );
		}

		public static Vector3 operator*(Vector3 A, float Scale)
		{
			return( new Vector3(A.X * Scale, A.Y * Scale, A.Z * Scale) );
		}

		public double Length()
		{
			return( Math.Sqrt( (X * X) + (Y * Y) + (Z * Z) ) );
		}

		public static Vector3 Normalize(Vector3 V)
		{
			double Length = V.Length();
			Vector3 ReturnVector3 = V;

			if (Length != 0)
			{
				ReturnVector3 = new Vector3( (float)(V.X / Length), (float)(V.Y / Length), 
					(float)(V.Z / Length) );
			}

			return(ReturnVector3);
		}

		public static float Dot(Vector3 V1, Vector3 V2)
		{
			return( (V1.X * V2.X) + (V1.Y * V2.Y) + (V1.Z * V2.Z) );
		}

		public void Normalize()
		{
			double Length = this.Length();

			if (Length != 0)
			{
				X = (float)(X / Length);
				Y = (float)(Y / Length);
				Z = (float)(Z / Length);
			}
		}

		public static Vector3 Cross(Vector3 A, Vector3 B)
		{
			return( new Vector3( ((A.Y * B.Z) - (A.Z * B.Y)),
				((A.Z * B.X) - (A.X * B.Z)), ((A.X * B.Y) - (A.Y * B.X)) ) );
		}

		public static Vector3 PointsToVector3(float X, float Y, float Z, float X2,
			float Y2, float Z2)
		{
			return( new Vector3(X - X2, Y - Y2, Z - Z2) );
		}

		public override string ToString()
		{
			return( "(" + X.ToString() + ", " + Y.ToString() + ", " + Z.ToString() + ")" );
		}

	}
}
