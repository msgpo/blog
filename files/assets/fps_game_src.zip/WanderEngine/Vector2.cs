using System;

namespace WanderEngine
{
	/// <summary>
	/// Summary description for Vector2.
	/// </summary>
	public class Vector2
	{
		public float X = 0.0f, Y = 0.0f;

		public Vector2()
		{
			//Do nothing
		}

		public Vector2(float X, float Y)
		{
			//Copy values
			this.X = X;
			this.Y = Y;
		}

		public static Vector2 operator+(Vector2 A, Vector2 B)
		{
			return( new Vector2(A.X + B.X, A.Y + B.Y) );
		}

		public static Vector2 operator-(Vector2 A, Vector2 B)
		{
			return( new Vector2(A.X - B.X, A.Y - B.Y) );
		}

		public static Vector2 operator*(Vector2 A, Vector2 B)
		{
			return( new Vector2(A.X * B.X, A.Y * B.Y) );
		}

		public static Vector2 operator/(Vector2 A, Vector2 B)
		{
			return( new Vector2(A.X / B.X, A.Y / B.Y) );
		}

		public double Length()
		{
			return( Math.Sqrt( (X * X) + (Y * Y) ) );
		}

		public override string ToString()
		{
			return( "(" + X.ToString() + ", " + Y.ToString() + ")" );
		}

	}
}
