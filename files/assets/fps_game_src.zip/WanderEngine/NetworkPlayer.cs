using System;
using System.Collections;

namespace WanderEngine
{
	/// <summary>
	/// Summary description for NetworkPlayer.
	/// </summary>
	
	public class NetworkPlayerState
	{
		public float X = 0.0f;
		public float Z = 0.0f;
		public float Yaw = 0.0f;
		
		public NetworkPlayerState()
		{
			//Do nothing
		}

		public NetworkPlayerState(float X, float Z, float Yaw)
		{
			//Copy values
			this.X = X;
			this.Z = Z;
			this.Yaw = Yaw;
		}
	}

	public class NetworkPlayer
	{
		public int ID = -1;
		public String Name = "No Name";
		public String ModelName = "";
		public MD2Model PlayerModel;
		public NetworkPlayerState InitialState = null;
		
		public NetworkPlayer(int ID, String Name, String ModelName, NetworkPlayerState InitialState)
		{
			//Copy values
			this.ID = ID;
			this.Name = Name;
			this.ModelName = ModelName;
			this.InitialState = InitialState;
		}

		public void SetState(NetworkPlayerState NewState)
		{
			lock(PlayerModel)
			{
				if (NewState != null)
				{
					if ( (NewState.X != PlayerModel.Position.X) || (NewState.Z != PlayerModel.Position.Z) )
					{
						PlayerModel.ModelState = AnimationState.Run;
					}
					else
					{
						PlayerModel.ModelState = AnimationState.Stand;
					}

					//Copy state
					PlayerModel.Position.X = NewState.X;
					PlayerModel.Position.Z = NewState.Z;
					PlayerModel.Yaw = NewState.Yaw;
				}
			}
		}

		public void Update(float TimeElapsed)
		{
			lock(PlayerModel)
			{
				PlayerModel.Update(TimeElapsed);
			}
		}
	}
}
