using System;
using System.IO;
using System.Drawing;
using System.Drawing.Imaging;

//OpenGL
using Tao.OpenGl;
using Tao.Platform.Windows;

namespace WanderEngine
{
	/// <summary>
	/// Summary description for Texture.
	/// </summary>
	
	public class Texture
	{
		public int Width, Height;
		public int TextureID;
						
		public Texture(String FileName)
		{
			Bitmap CurrentImage = new Bitmap(FileName);
			LoadBitmap(CurrentImage, false);
			CurrentImage.Dispose();
		}

		public Texture(String FileName, bool IsSkyBox)
		{
			Bitmap CurrentImage = new Bitmap(FileName);
			LoadBitmap(CurrentImage, IsSkyBox);
			CurrentImage.Dispose();
		}

		public Texture(Bitmap ExistingImage)
		{
			LoadBitmap(ExistingImage, false);
		}

		private void LoadBitmap(Bitmap CurrentImage, bool IsSkyBox)
		{
			//Extract data
			Width = CurrentImage.Width;
			Height = CurrentImage.Height;

			//Flip image
			CurrentImage.RotateFlip(RotateFlipType.RotateNoneFlipY);
			
			Rectangle ImageRect = new Rectangle(0, 0, Width, Height);
			BitmapData Data = CurrentImage.LockBits(ImageRect, ImageLockMode.ReadOnly,
				PixelFormat.Format24bppRgb);

			//Generate ID
			TextureID = -1;
			Gl.glGenTextures(1, out TextureID);

			//Setup texture
			Gl.glBindTexture(Gl.GL_TEXTURE_2D, TextureID);

			if (IsSkyBox)
			{
				Gl.glTexParameteri(Gl.GL_TEXTURE_2D, Gl.GL_TEXTURE_WRAP_S, Gl.GL_CLAMP_TO_EDGE);
				Gl.glTexParameteri(Gl.GL_TEXTURE_2D, Gl.GL_TEXTURE_WRAP_T, Gl.GL_CLAMP_TO_EDGE);
			}
			else
			{
				Gl.glTexParameteri(Gl.GL_TEXTURE_2D, Gl.GL_TEXTURE_WRAP_S, Gl.GL_REPEAT);
				Gl.glTexParameteri(Gl.GL_TEXTURE_2D, Gl.GL_TEXTURE_WRAP_T, Gl.GL_REPEAT);			
			}

			Gl.glTexParameteri(Gl.GL_TEXTURE_2D, Gl.GL_TEXTURE_MIN_FILTER, Gl.GL_LINEAR_MIPMAP_LINEAR);
			Gl.glTexParameteri(Gl.GL_TEXTURE_2D, Gl.GL_TEXTURE_MAG_FILTER, Gl.GL_LINEAR);			
			
			Glu.gluBuild2DMipmaps(Gl.GL_TEXTURE_2D, (int)Gl.GL_RGB, Width, Height, Gl.GL_BGR_EXT, 
				Gl.GL_UNSIGNED_BYTE, Data.Scan0);
		
			CurrentImage.UnlockBits(Data);
		}
	}
}
