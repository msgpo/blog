using System;
using System.Windows.Forms;
using System.IO;
using System.Drawing;
using System.Text.RegularExpressions;
using System.Runtime.InteropServices;
using System.Net;
using System.Collections;

//DirectX
using Microsoft.DirectX;

//OpenGL
using Tao.OpenGl;
using Tao.Platform.Windows;

//DirectInput
using Microsoft.DirectX.DirectInput;
using DirectInput = Microsoft.DirectX.DirectInput;

//DirectPlay
using Microsoft.DirectX.DirectPlay;
using DirectPlay = Microsoft.DirectX.DirectPlay;
using Voice = Microsoft.DirectX.DirectPlay.Voice;

//DirectSound
using Microsoft.DirectX.DirectSound;
using DirectSound = Microsoft.DirectX.DirectSound;

namespace WanderEngine
{
	/// <summary>
	/// Summary description for Engine.
	/// </summary>

	public enum MessageType
	{
		AddPlayer, RemovePlayer, AddCurrentPlayer, UpdateState, PrivateMessage, ChatMessage
	}

	public class ChatMessageEventArgs : System.EventArgs
	{
		public int SenderID = -1;
		public String ChatMessage = "";
		public bool IsPrivate = false;

		public ChatMessageEventArgs(int SenderID, String ChatMessage, bool IsPrivate)
		{
			//Copy values
			this.SenderID = SenderID;
			this.ChatMessage = ChatMessage;
			this.IsPrivate = IsPrivate;
		}
	}

	public class PlayerEventArgs : System.EventArgs
	{
		public int ID = -1;
		public String Name = "";
		public String ModelName = "";
		public NetworkPlayerState InitialState = null;

		public PlayerEventArgs(int ID, String Name, String ModelName, NetworkPlayerState InitialState)
		{
			//Copy values
			this.ID = ID;
			this.Name = Name;
			this.ModelName = ModelName;
			this.InitialState = InitialState;
		}
	}

	public class TriggerEventArgs : System.EventArgs
	{
		public String Name = "";

		public TriggerEventArgs(String Name)
		{
			//Copy values
			this.Name = Name;
		}
	}

	public class Engine
	{
		#region Imported Functions

		[DllImport("user32.dll", EntryPoint = "ShowCursor")]
		private static extern long ShowCursor(long bShow);

		[DllImport("user32.dll", EntryPoint = "SetCursorPos")] 
		static public extern bool SetCursorPos(int X, int Y);

		#endregion

		#region Engine Variables

		private float TimeElapsed = 0.0f;
		private bool m_IsPaused = false;
		private bool m_ProcessInput = false;
		private bool InputJustEnabled = false;

		#endregion
 
		#region Window Variables

		private SimpleOpenGlControl RenderTarget = null;
		private Form RenderForm = null;
		
		#endregion

		#region Mapping Variables

		private CommandSet PlayerState = new CommandSet();
		private ControlConfig ControlCfg = new ControlConfig();
		private BSPFile CurrentMap = null;
		private Camera MapCamera = new Camera();
		private Frustrum MapFrustrum = new Frustrum();
		private Vector3 SpawnPoint = new Vector3();
		private float WalkBias = 0.0f;
		private Trigger CollisionTrigger = null, LastTrigger = null;
		private Font3D NameFont;
		
		#endregion

		#region Input Variables

		private DirectInput.Device MouseDevice = null;
		private DirectInput.Device KeyboardDevice = null;

		#endregion
		
		#region Network Variables

		public static readonly int EveryoneID = (int)DirectPlay.PlayerID.AllPlayers;
		private static readonly System.Guid ApplicationGuid = new Guid("{DCC56EE8-0265-4e9b-91E8-A1210B12E0AC}");
		private static readonly int Port = 12548;

		private Hashtable NetworkPlayers = new Hashtable();
		private String m_PlayerName = "";
		private String m_ModelName = "";
		private Client DPClient = null;
		private bool m_Connected = false;
		private int m_NetworkID = -1;
		private bool NextStateReady = true;
		private bool SendSteadyState = true;
		private NetworkPlayerState LastState = new NetworkPlayerState(float.NaN, float.NaN, float.NaN);
		
		private ArrayList IncomingPlayers = new ArrayList();
		private ArrayList OutgoingPlayerIDs = new ArrayList();

		private Voice.Client ClientVoice = null;
		private bool VoiceEnabled = false;

		#endregion

		#region Event Variables

		public delegate void ConnectedToServerHandler(object sender, System.EventArgs e);
		public event ConnectedToServerHandler ConnectedToServer;

		public delegate void DisconnectedFromServerHandler(object sender, System.EventArgs e);
		public event DisconnectedFromServerHandler DisconnectedFromServer;

		public delegate void ChatMessageRecievedHandler(object sender, WanderEngine.ChatMessageEventArgs e);
		public event ChatMessageRecievedHandler ChatMessageRecieved;

		public delegate void AddPlayerHandler(object sender, PlayerEventArgs e);
		public event AddPlayerHandler AddPlayer;

		public delegate void RemovePlayerHandler(object sender, PlayerEventArgs e);
		public event RemovePlayerHandler RemovePlayer;

		public delegate void TriggerActivatedHandler(object sender, TriggerEventArgs e);
		public event TriggerActivatedHandler TriggerActivated;

		#endregion
									
		//Properties
		public bool IsPaused
		{
			get { return(m_IsPaused); }
			set { m_IsPaused = value; }
		}

		public bool ProcessInput
		{
			get { return(m_ProcessInput); }
			set { EnableInputProcessing(value); }
		}

		public bool Connected
		{
			get { return(m_Connected); }
		}

		public String PlayerName
		{
			get { return(m_PlayerName); }
			set { m_PlayerName = value; }
		}

		public String ModelName
		{
			get { return(m_ModelName); }
			set { m_ModelName = value; }
		}

		public int NetworkID
		{
			get { return(m_NetworkID); }
		}

		public Engine(Form RenderForm, SimpleOpenGlControl RenderTarget)
		{
			//Copy values
			this.RenderForm = RenderForm;
			this.RenderTarget = RenderTarget;

			//Initialize engine
			InitializeAll();
		}

		#region Initialization Routines

		private void InitializeAll()
		{
			InitializeGraphics();
			InitializeInput();
			InitializeNetwork();

			//Initialize name font
			NameFont = new Font3D(RenderTarget, 
				Application.StartupPath + @"\fonts\font.bmp");
		}

		private void InitializeGraphics()
		{
			try
			{
				Gl.glClearColor(0.0f, 0.0f, 0.0f, 0.0f);
				
				Gl.glShadeModel(Gl.GL_SMOOTH);
				Gl.glEnable(Gl.GL_TEXTURE_2D);
								
				//Depth buffer
				Gl.glEnable(Gl.GL_DEPTH_TEST);
				Gl.glClearDepth(1.0f);
				Gl.glDepthFunc(Gl.GL_LEQUAL);
				Gl.glDepthRange(0.0f, 1.0f);
				
				Gl.glHint(Gl.GL_PERSPECTIVE_CORRECTION_HINT, Gl.GL_NICEST);

				//Culling
				Gl.glCullFace(Gl.GL_FRONT);
				Gl.glEnable(Gl.GL_CULL_FACE);

				//Clear background
				Gl.glClear(Gl.GL_COLOR_BUFFER_BIT | Gl.GL_DEPTH_BUFFER_BIT);
				
				OnResizeControl();			
			}
			catch(Exception ex)
			{
				throw new Exception("Failed to initialize OpenGL", ex);
			}
		}

		private void InitializeInput()
		{
			try
			{
				//Keyboard
				KeyboardDevice = new DirectInput.Device(SystemGuid.Keyboard);
				KeyboardDevice.SetCooperativeLevel(RenderForm, DirectInput.CooperativeLevelFlags.NonExclusive | DirectInput.CooperativeLevelFlags.Foreground);
				KeyboardDevice.Acquire();	
			}
			catch
			{
				//Do nothing
			}

			try
			{
				//Mouse
				MouseDevice = new DirectInput.Device(SystemGuid.Mouse);
				MouseDevice.SetCooperativeLevel(RenderForm, DirectInput.CooperativeLevelFlags.NonExclusive | DirectInput.CooperativeLevelFlags.Foreground);
				MouseDevice.Acquire();
			}
			catch
			{
				//Do nothing
			}			
		}

		private void InitializeNetwork()
		{
			if (DPClient != null)
			{
				DPClient.Dispose();
				DPClient = null;
			}

			DPClient = new Client();

			//Hook events
			DPClient.FindHostResponse += new FindHostResponseEventHandler(DPClient_FindHostResponse);
			DPClient.ConnectComplete += new ConnectCompleteEventHandler(DPClient_ConnectComplete);
			DPClient.SessionTerminated += new SessionTerminatedEventHandler(DPClient_SessionTerminated);
			DPClient.Receive += new ReceiveEventHandler(DPClient_Receive);
		
			//Hook default engine events
			ConnectedToServer += new ConnectedToServerHandler(Engine_ConnectedToServer);
			DisconnectedFromServer += new DisconnectedFromServerHandler(Engine_DisconnectedFromServer);
			ChatMessageRecieved += new ChatMessageRecievedHandler(Engine_ChatMessageRecieved);
			AddPlayer += new AddPlayerHandler(Engine_AddPlayer);
			RemovePlayer += new RemovePlayerHandler(Engine_RemovePlayer);
			TriggerActivated += new TriggerActivatedHandler(Engine_TriggerActivated);
		}

		#endregion

		#region Destruction Routines

		public void DestroyAll()
		{
			DestroyInput();
			DestroyNetwork();
		}

		private void DestroyInput()
		{
			if (KeyboardDevice != null)
			{
				KeyboardDevice.Unacquire();
				KeyboardDevice.Dispose();
				KeyboardDevice = null;
			}

			if (MouseDevice != null)
			{
				MouseDevice.Unacquire();
				MouseDevice.Dispose();
				MouseDevice = null;
			}
		}

		private void DestroyNetwork()
		{
			DisconnectFromServer();
		}

		#endregion

		#region Mapping Routines

		public void LoadMap(String DirectoryPath, String MapName)
		{
			//Set directory for loading textures
			Directory.SetCurrentDirectory(DirectoryPath);

			//Load the map
			CurrentMap = new BSPFile(MapName);

			//Reset matrices
			Gl.glMatrixMode(Gl.GL_MODELVIEW);
			Gl.glLoadIdentity();
			Gl.glMatrixMode(Gl.GL_PROJECTION);
			Gl.glLoadIdentity();

			//Load info_player_deathmatch point
			SpawnPoint = new Vector3();
			BSPEntity[] AllSpawnPoints = CurrentMap.Entities.SeekEntitiesByClassname("info_player_deathmatch");

			if (AllSpawnPoints.Length > 0)
			{
				//Set camera origin
				String[] Origins = AllSpawnPoints[0].SeekValuesByArgument("origin");
				if (Origins.Length > 0)
				{
					//Parse coordinates
					String[] Coords = Regex.Split(Origins[0], " ");

					if (Coords.Length == 3)
					{
						try
						{
							//Invert X and Z; swap Y and Z
							SpawnPoint.X += -float.Parse(Coords[0]);
							SpawnPoint.Z += -float.Parse(Coords[1]);
							SpawnPoint.Y += float.Parse(Coords[2]);
						}
						catch
						{
							//Do nothing
						}
					}
				}

				//Set view angle
				String[] Angles = AllSpawnPoints[0].SeekValuesByArgument("angle");

				if (Angles.Length > 0)
				{
					try
					{
						float Angle = float.Parse(Angles[0]);
						MapCamera.Yaw = 90.0f - Angle;
					}
					catch
					{
						//Do nothing
					}
				}
			}
			
			OnResizeControl();

			//Set spawn point
			MapCamera.MoveCameraTo(SpawnPoint);
			MapCamera.MoveCameraUpDown(5.0f);
		}

		#endregion

		#region Rendering Routines

		public void Render()
		{
			if (CurrentMap != null)
			{
				//Setup OpenGL for rendering
				PrepareRenderMap();

				//Update the view
				MapCamera.UpdateView();

				//Update the current frustrum
				MapFrustrum.UpdateFrustrum();

				//Render the map
				CurrentMap.RenderLevel(MapCamera.Position, MapFrustrum);

				//Render player models
				lock(NetworkPlayers)
				{
					foreach(NetworkPlayer CurrentPlayer in NetworkPlayers.Values)
					{
						CurrentPlayer.Update(TimeElapsed);

						//Draw name
						NameFont.Render(CurrentPlayer.PlayerModel.Position.X -
							CurrentPlayer.PlayerModel.Center.X,
							CurrentPlayer.PlayerModel.BoundMax.Y,
							CurrentPlayer.PlayerModel.Position.Z +
							CurrentPlayer.PlayerModel.Center.Z,
							CurrentPlayer.Name);
					}
				}
			}
			else
			{
				//Show black background
				Gl.glClear(Gl.GL_COLOR_BUFFER_BIT);
			}
		}

		private void PrepareRenderMap()
		{
			Gl.glClear(Gl.GL_DEPTH_BUFFER_BIT | Gl.GL_STENCIL_BUFFER_BIT);
			Gl.glLoadIdentity();
		}

		#endregion

		#region Networking Routines

		public void ConnectToServer(System.Net.IPAddress HostIP)
		{
			//Set state
			m_Connected = false;

			//Add information
			Address DeviceAddress = new Address();
			DeviceAddress.ServiceProvider = Address.ServiceProviderTcpIp;

			Address HostAddress = new Address( new IPEndPoint( HostIP, Port ) );
						
			PlayerInformation PlayerInfo = new PlayerInformation();
			PlayerInfo.Name = m_PlayerName;

			DPClient.SetClientInformation(PlayerInfo, SyncFlags.ClientInformation);

			ApplicationDescription AppDesc = new ApplicationDescription();
			AppDesc.GuidApplication = ApplicationGuid;
			
			//Search for hosts
			DPClient.FindHosts(AppDesc, HostAddress, DeviceAddress, null, 0, 0, 0, FindHostsFlags.None);
		}

		private void DisconnectFromServer()
		{
			if (m_Connected)
			{
				if (VoiceEnabled)
				{
					ClientVoice.Dispose();
					ClientVoice = null;
				}

				//Send disconnection message
				NetworkPacket Packet = new NetworkPacket();
				Packet.Write(MessageType.RemovePlayer);
				Packet.Write(m_NetworkID);
				Packet.Write(m_PlayerName);
				DPClient.Send(Packet, 0, SendFlags.Guaranteed | SendFlags.NoLoopback);

				m_Connected = false;
				
				if (DPClient != null)
				{
					DPClient.Dispose();
					DPClient = null;
				}
			}
		}

		private void DPClient_ConnectComplete(object sender, ConnectCompleteEventArgs e)
		{
			if (e.Message.ResultCode == DirectPlay.ResultCode.Success)
			{
				//Set state
				m_Connected = true;
				m_NetworkID = e.Message.LocalPlayerId;

				//Send add player request
				NetworkPacket SendPacket = new NetworkPacket();
				SendPacket.Write(MessageType.AddPlayer);
				SendPacket.Write(m_NetworkID);
				SendPacket.Write(m_PlayerName);
				SendPacket.Write(m_ModelName);
				DPClient.Send(SendPacket, 0, SendFlags.Guaranteed);

				//Fire event
				ConnectedToServer(this, null);
			}
		}

		private void DPClient_SessionTerminated(object sender, SessionTerminatedEventArgs e)
		{
			DisconnectFromServer();

			//Fire event
			DisconnectedFromServer(this, null);
		}

		private void DPClient_FindHostResponse(object sender, FindHostResponseEventArgs e)
		{
			//Connect to the first host found
			DPClient.Connect(e.Message.ApplicationDescription, e.Message.AddressSender,
				e.Message.AddressDevice, null, ConnectFlags.OkToQueryForAddressing);		
		}

		private void DPClient_Receive(object sender, ReceiveEventArgs e)
		{			
			try
			{
				NetworkPacket Packet = e.Message.ReceiveData;
				MessageType MsgType = (MessageType)Packet.Read( typeof(MessageType) );

				//State variables
				int CurrentID = -1;
				String CurrentName = "";
				String PlayerModelName = "";
				NetworkPacket SendPacket;
				float X = 0.0f;
				float Z = 0.0f;
				float Yaw = 0.0f;

				switch(MsgType)
				{
					case MessageType.PrivateMessage:
					case MessageType.ChatMessage:
						CurrentID = (int)Packet.Read(typeof(int));
						String Message = Packet.ReadString();

						//Fire event
						ChatMessageRecieved( this, 
							new ChatMessageEventArgs( CurrentID, Message, (MsgType == MessageType.PrivateMessage) ) );
						break;

					case MessageType.AddPlayer:
						CurrentID = (int)Packet.Read(typeof(int));
						CurrentName = Packet.ReadString();
						PlayerModelName = Packet.ReadString();
					
						if (CurrentID != m_NetworkID)
						{
							//Send response packet
							SendPacket = new NetworkPacket();
							SendPacket.Write(MessageType.AddCurrentPlayer);
							SendPacket.Write(CurrentID);
							SendPacket.Write(m_PlayerName);
							SendPacket.Write(m_ModelName);
							SendPacket.Write(MapCamera.Position.X);
							SendPacket.Write(MapCamera.Position.Z);
							SendPacket.Write(90.0f - MapCamera.Yaw);
							DPClient.Send(SendPacket, 0, SendFlags.Guaranteed);

							//Fire event
							AddPlayer( this, new PlayerEventArgs(CurrentID, CurrentName, PlayerModelName, null) );
						}
						break;

					case MessageType.AddCurrentPlayer:
						CurrentID = (int)Packet.Read(typeof(int));
						CurrentName = Packet.ReadString();
						PlayerModelName = Packet.ReadString();
						X = (float)Packet.Read(typeof(float));
						Z = (float)Packet.Read(typeof(float));
						Yaw = (float)Packet.Read(typeof(float));

						if (CurrentID != m_NetworkID)
						{
							//Fire event
							AddPlayer( this, new PlayerEventArgs( CurrentID, CurrentName, PlayerModelName,
								new NetworkPlayerState(X, Z, Yaw) ) );
						}
						break;

					case MessageType.RemovePlayer:
						CurrentID = (int)Packet.Read(typeof(int));
						CurrentName = Packet.ReadString();

						if (CurrentID != m_NetworkID)
						{
							//Fire event
							RemovePlayer( this, new PlayerEventArgs(CurrentID, CurrentName, "", null) );
						}
						break;

					case MessageType.UpdateState:
						CurrentID = (int)Packet.Read(typeof(int));
						X = (float)Packet.Read(typeof(float));
						Z = (float)Packet.Read(typeof(float));
						Yaw = (float)Packet.Read(typeof(float));

						if (CurrentID != m_NetworkID)
						{
							lock(NetworkPlayers)
							{
								if (NetworkPlayers.ContainsKey(CurrentID))
								{
									NetworkPlayer CurrentPlayer = (NetworkPlayer)NetworkPlayers[CurrentID];
									CurrentPlayer.SetState( new NetworkPlayerState(X, Z, Yaw) );
								}
							}
						}
						else
						{
							NextStateReady = true;
						}
						break;
				}
			}
			catch
			{
				//Do nothing
			}
		}

		public void SendMessage(int ID, String Message, bool IsPrivate)
		{
			NetworkPacket Packet = new NetworkPacket();

			if (IsPrivate)
			{
				Packet.Write(MessageType.PrivateMessage);
			}
			else
			{
				Packet.Write(MessageType.ChatMessage);
			}

			//Format Player ID (int), Message (string)
			Packet.Write(ID);
			Packet.Write(Message);

			DPClient.Send(Packet, 0, SendFlags.Guaranteed);
		}

		private void SendMovementState()
		{
			float NewYaw = 90.0f - MapCamera.Yaw;

			if ( (MapCamera.Position.X != LastState.X) ||
				(MapCamera.Position.Z != LastState.Z) ||
				(MapCamera.Yaw != LastState.Yaw) )
			{
				//Set state
				SendSteadyState = true;
				NextStateReady = false;

				//Copy state
				LastState.X = MapCamera.Position.X;
				LastState.Z = MapCamera.Position.Z;
				LastState.Yaw = MapCamera.Yaw;

				NetworkPacket Packet = new NetworkPacket();
				Packet.Write((int)MessageType.UpdateState);
				Packet.Write(m_NetworkID);
				Packet.Write(MapCamera.Position.X);
				Packet.Write(MapCamera.Position.Z);
				Packet.Write(NewYaw);

				//Send state
				DPClient.Send(Packet, 0, SendFlags.Sync);
			}
			else if (SendSteadyState)
			{
				//Set state
				SendSteadyState = false;

				NetworkPacket Packet = new NetworkPacket();
				Packet.Write((int)MessageType.UpdateState);
				Packet.Write(m_NetworkID);
				Packet.Write(MapCamera.Position.X);
				Packet.Write(MapCamera.Position.Z);
				Packet.Write(NewYaw);

				//Send state
				DPClient.Send(Packet, 0, SendFlags.Sync);
			}
		}

		public void EnableVoice()
		{
			if (m_Connected)
			{
				ClientVoice = new Voice.Client(DPClient);
				
				//Configure sound
				Voice.SoundDeviceConfig SndConfig = new Voice.SoundDeviceConfig();
				SndConfig.Flags = Voice.SoundConfigFlags.AutoSelect;
				SndConfig.GuidPlaybackDevice = DSoundHelper.DefaultPlaybackDevice;
				SndConfig.GuidCaptureDevice = DSoundHelper.DefaultCaptureDevice;
				SndConfig.Window = RenderForm;

				//Configure client
				Voice.ClientConfig ClientCfg = new Voice.ClientConfig();
				ClientCfg.Flags = Voice.ClientConfigFlags.AutoVoiceActivated |
					Voice.ClientConfigFlags.AutoRecordVolume;

				ClientCfg.RecordVolume = (int)Voice.RecordVolume.Last;
				ClientCfg.PlaybackVolume = (int)Voice.PlaybackVolume.Default;
				ClientCfg.Threshold = Voice.Threshold.Unused;
				ClientCfg.BufferQuality = Voice.BufferQuality.Default;
				ClientCfg.BufferAggressiveness = Voice.BufferAggressiveness.Default;

				//Attempt to connect
				try
				{
					ClientVoice.Connect(SndConfig, ClientCfg, Voice.VoiceFlags.Sync);
				}
				catch(Voice.RunSetupException)
				{
					Voice.Test VTest = new Voice.Test();
					VTest.CheckAudioSetup();

					//Connect again
					ClientVoice.Connect(SndConfig, ClientCfg, Voice.VoiceFlags.Sync);
				}

				int[] Targets = new int[1];
				Targets[0] = (int)Voice.PlayerId.AllPlayers;
				ClientVoice.TransmitTargets = Targets;

				VoiceEnabled = true;
			}
		}

		public void SetVoiceTarget(int TargetID)
		{
			if (VoiceEnabled)
			{
				int[] Targets = new int[1];
				Targets[0] = TargetID;
				ClientVoice.TransmitTargets = Targets;
			}
		}

		public void DisableVoice()
		{
			if (VoiceEnabled)
			{
				ClientVoice.TransmitTargets = new int[] { };
			}
		}

		private void Engine_ConnectedToServer(object sender, EventArgs e)
		{
			//Do nothing
		}

		private void Engine_DisconnectedFromServer(object sender, EventArgs e)
		{
			//Do nothing
		}

		private void Engine_ChatMessageRecieved(object sender, ChatMessageEventArgs e)
		{
			//Do nothing
		}

		private void Engine_AddPlayer(object sender, PlayerEventArgs e)
		{
			//Add to the list
			lock(IncomingPlayers)
			{
				IncomingPlayers.Add( new NetworkPlayer(e.ID, e.Name, e.ModelName, e.InitialState) );
			}
		}

		private void Engine_RemovePlayer(object sender, PlayerEventArgs e)
		{
			//Add to the list
			lock(OutgoingPlayerIDs)
			{
				OutgoingPlayerIDs.Add(e.ID);
			}
		}

		#endregion

		#region Input Routines

		private void EnableInputProcessing(bool Enabled)
		{
			m_ProcessInput = Enabled;

			//Update cursor
			if (Enabled)
			{
				InputJustEnabled = true;
				ShowCursor(0);
			}
			else
			{
				ShowCursor(1);
			}
		}

		private void UpdateInput(ref CommandSet State)
		{
			//Clear movement vector
			State.PlayerMovement.X = 0.0f;
			State.PlayerMovement.Y = 0.0f;
			State.PlayerMovement.Z = 0.0f;

			//Reset look state
			State.PlayerLook.X = 0;
			State.PlayerLook.Y = 0;

			if (m_ProcessInput)
			{
				ProcessKeyboardEvents(ref State);
				ProcessMouseEvents(ref State);
			}
		}

		private void ProcessKeyboardEvents(ref CommandSet State)
		{
			try
			{
				KeyboardState KbState = KeyboardDevice.GetCurrentKeyboardState();

				if (KbState[ ControlCfg.MoveForward ])
				{
					State.PlayerMovement.Z = 1.0f;
				}
				else if (KbState[ ControlCfg.MoveBack ])
				{
					State.PlayerMovement.Z = -1.0f;
				}

				if (KbState[ ControlCfg.LeftStrafe ])
				{
					State.PlayerMovement.X = -1.0f;
				}
				else if (KbState[ ControlCfg.RightStrafe ])
				{
					State.PlayerMovement.X = 1.0f;
				}
			}
			catch
			{
				//Do nothing
			}
		}

		private void ProcessMouseEvents(ref CommandSet State)
		{
			try
			{
				MouseState StateData = MouseDevice.CurrentMouseState;
				byte[] Buttons = StateData.GetMouseButtons();
				
				//Lock cursor
				Point CursorCoord = RenderTarget.PointToScreen( new Point(RenderTarget.Width / 2, RenderTarget.Height / 2) );
				SetCursorPos(CursorCoord.X, CursorCoord.Y);

				if (!InputJustEnabled)
				{
					State.PlayerLook.X = -StateData.X;

					if (ControlCfg.InvertMouse)
					{
						State.PlayerLook.Y = StateData.Y;				
					}
					else
					{
						State.PlayerLook.Y = -StateData.Y;
					}				
				}
				else
				{
					InputJustEnabled = false;
				}
			}
			catch
			{
				//Do nothing
			}
		}

		public void ReAcquireInput()
		{
			if (MouseDevice != null)
			{
				try
				{
					MouseDevice.Acquire();
				}
				catch
				{
					//Do nothing
				}
			}

			if (KeyboardDevice != null)
			{
				try
				{
					KeyboardDevice.Acquire();
				}
				catch
				{
					//Do nothing
				}
			}
		}

		#endregion

		#region Main Routines

		public void UpdateFrame(float TimeElapsed)
		{
			this.TimeElapsed = TimeElapsed;

			if (!m_IsPaused)
			{
				if (CurrentMap != null)
				{
					//Process incoming players
					lock(IncomingPlayers)
					{
						foreach(NetworkPlayer NewPlayer in IncomingPlayers)
						{
							//Load the player's model
							Directory.SetCurrentDirectory(Application.StartupPath + @"\models");
							NewPlayer.PlayerModel = new MD2Model(NewPlayer.ModelName + ".md2", 
								NewPlayer.ModelName + ".bmp");

							if (NewPlayer.InitialState == null)
							{
								//Set to spawn point
								NewPlayer.PlayerModel.Position = new Vector3(SpawnPoint.X,
									0.0f, SpawnPoint.Z);
							}
							else
							{
								NewPlayer.PlayerModel.Position = new Vector3(NewPlayer.InitialState.X,
									0.0f, NewPlayer.InitialState.Z);

								NewPlayer.PlayerModel.Yaw = NewPlayer.InitialState.Yaw;
							}

							//Add to the list
							lock(NetworkPlayers)
							{
								NetworkPlayers[NewPlayer.ID] = NewPlayer;
							}
						}

						//Clear list
						IncomingPlayers.Clear();
					}

					//Process outgoing players
					lock(OutgoingPlayerIDs)
					{
						//Remove each player
						foreach(int ID in OutgoingPlayerIDs)
						{
							lock(NetworkPlayers)
							{
								if (NetworkPlayers.ContainsKey(ID))
								{
									NetworkPlayers.Remove(ID);
								}
							}
						}

						//Clear list
						OutgoingPlayerIDs.Clear();
					}
					
					//Update state
					UpdateInput(ref PlayerState);
					UpdatePlayerState(PlayerState);

					//Send state to game server
					if ( (m_Connected) && (NextStateReady) )
					{
						SendMovementState();
					}
				}

				Render();
			}
		}

		private void UpdatePlayerState(CommandSet PlayerState)
		{
			float LookHorzScale = TimeElapsed * ControlCfg.MouseSpeedHorz;
			float LookVertScale = TimeElapsed * ControlCfg.MouseSpeedVert;
			float MoveScale = TimeElapsed * ControlCfg.MoveSpeed;

			//Update camera
			MapCamera.SetMouseView(PlayerState.PlayerLook.X * LookHorzScale,
				PlayerState.PlayerLook.Y * LookVertScale);

			if ( (PlayerState.PlayerMovement.Z != 0.0f) || (PlayerState.PlayerMovement.X != 0.0f) )
			{
				float FrontBack = PlayerState.PlayerMovement.Z * MoveScale;
				float LeftRight = PlayerState.PlayerMovement.X * MoveScale;
				
				//Do collision detection
				Vector3 ProjectedPos = Camera.ProjectVector(new Vector3(), FrontBack, LeftRight, MapCamera.Yaw);

				//if (!TryStepUpAndSlide(ProjectedPos))
				//{
					TrySlide( new Vector3(MapCamera.Position.X, 
						SpawnPoint.Y + 5.0f, MapCamera.Position.Z),
						ProjectedPos);
				//}
				
				//Update head bob for forward/backward movement only
				if (PlayerState.PlayerMovement.Z != 0.0f)
				{
					float ScaledTime = TimeElapsed * 100;
					WalkBias = Global.CapAngle(WalkBias + (5.0f * ScaledTime));
					float Dy = (Global.SinDeg(WalkBias) / 7.0f) * ScaledTime;

					MapCamera.MoveCameraUpDown(Dy);
				}
			}

			//Detect trigger collisions
			LastTrigger = CollisionTrigger;
			CollisionTrigger = CurrentMap.DetectTriggerCollisions(MapCamera.Position);

			if ( (CollisionTrigger != null) && (LastTrigger != CollisionTrigger) )
			{
				TriggerActivated(this, new TriggerEventArgs(CollisionTrigger.Name));
			}

			//Simulate gravity
			/*
			CurrentMap.DetectCollisionRay(MapCamera.Position, MapCamera.Position - PlayerState.MaxHeight);

			if (CurrentMap.CollisionInfo.Fraction > 0.0f)
			{
				float GoalY = 50.0f + CurrentMap.CollisionInfo.EndPoint.Y;

				if (GoalY < MapCamera.Position.Y)
				{
					float Distance = Math.Abs( Math.Abs(MapCamera.Position.Y) - Math.Abs(GoalY) );

					if (Distance > 10.0f)
					{
						float MoveAmount = Math.Min(200.0f * TimeElapsed, Distance);
						MapCamera.MoveCameraUpDown(-MoveAmount);
					}
				}
			}
			*/
		}

		private bool TryStepUpAndSlide(Vector3 ProjectedPos)
		{
			//Test for stairs
			CurrentMap.DetectCollisionBox(MapCamera.Position, MapCamera.Position + PlayerState.Step, 
				PlayerState.BoundMin, PlayerState.BoundMax);

			if (CurrentMap.CollisionInfo.Fraction == 0)
			{
				return(false);
			}

			if (!TrySlide(CurrentMap.CollisionInfo.EndPoint, ProjectedPos))
			{
				return(false);
			}

			CurrentMap.DetectCollisionBox(MapCamera.Position, MapCamera.Position - PlayerState.Step, 
				PlayerState.BoundMin, PlayerState.BoundMax);

			if (CurrentMap.CollisionInfo.Fraction == 0)
			{
				return(false);
			}

			MapCamera.MoveCameraTo(CurrentMap.CollisionInfo.EndPoint);
			return(true);
		}

		private bool TrySlide(Vector3 SourceVector, Vector3 ProjectedPos)
		{
			Vector3 Slide = new Vector3();
			Vector3 DesiredMove = new Vector3(ProjectedPos.X, ProjectedPos.Y, ProjectedPos.Z);

			while ( (Math.Abs(DesiredMove.X) > 0.0001f) || (Math.Abs(DesiredMove.Y) > 0.0001f) || 
				(Math.Abs(DesiredMove.Z) > 0.0001f) )
			{
				CurrentMap.DetectCollisionBox(SourceVector, SourceVector + DesiredMove, 
					PlayerState.BoundMin, PlayerState.BoundMax);

				if (CurrentMap.CollisionInfo.Fraction > 0)
				{
					MapCamera.MoveCameraTo(CurrentMap.CollisionInfo.EndPoint);
					return(true);
				}

				Vector3 Normal = Vector3.Normalize(CurrentMap.CollisionInfo.Normal);
				Slide = DesiredMove - ( Normal * ( Vector3.Dot(Normal, DesiredMove) ) );
				DesiredMove = new Vector3(Slide.X, Slide.Y, Slide.Z);
			}

			return(false);
		}

		private void Engine_TriggerActivated(object sender, TriggerEventArgs e)
		{
			//Do nothing
		}

		#endregion

		#region OpenGL Event Handlers

		private void OnResizeControl()
		{
			//Set the viewport to the size of the window
			Gl.glViewport(0, 0, RenderTarget.Width, RenderTarget.Height);

			//Reset matrices
			Gl.glMatrixMode(Gl.GL_PROJECTION);
			Gl.glLoadIdentity();

			//Set perspective projection
			float AspectRatio = (RenderTarget.Width + 0.1f) / RenderTarget.Height;
			Glu.gluPerspective(70.0f, AspectRatio, 1.0f, 5000.0f);
			Gl.glMatrixMode(Gl.GL_MODELVIEW);
			Gl.glLoadIdentity();
		}

		#endregion
	}
}
