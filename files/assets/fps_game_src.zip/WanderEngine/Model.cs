using System;

//DirectX
using Microsoft.DirectX;

//Direct3D
using Microsoft.DirectX.Direct3D;
using Direct3D = Microsoft.DirectX.Direct3D;

namespace WanderEngine
{
	/// <summary>
	/// Summary description for Model.
	/// </summary>
	public class Model
	{
		//Internal state variables
		private AnimationRootFrame RootFrame;
		private Vector3 Center = new Vector3();
		private float Radius = 0.0f;

		public Model()
		{
			
		}
	}

	public class ModelAllocateHierarchy : AllocateHierarchy
	{
		public ModelAllocateHierarchy()
		{			
		}

		public override void SetUserDataInFrame(Frame frame)
		{

		}

		public override void SetUserDataInMeshContainer(MeshContainer container)
		{
			
		}
	}

	public class ModelFrame : Frame
	{
		//Internal state variables
		private Matrix CombinedMatrix = Matrix.Identity;

		//Properties
		public Matrix CombinedTransformationMatrix
		{
			get { return(CombinedMatrix); }
			set { CombinedMatrix = value; }
		}
	}

	public class ModelMeshContainer : MeshContainer
	{
		//Internal state variables
		private Texture[] Textures = null;
		private int NumAttributes = 0;
		private int NumInfluences = 0;
		private BoneCombination[] Bones = null;
		private ModelFrame[] FrameMatrices = null;
		private Matrix[] OffsetMatrices = null;

		//Properties
		public int NumberAttributes
		{
			get { return(NumAttributes); }
			set { NumAttributes = value; }
		}

		public int NumberInfluences
		{
			get { return(NumInfluences); }
			set { NumInfluences = value; }
		}

		//Get / set methods
		public Texture[] GetTextures()
		{
			return(Textures);
		}

		public void SetTextures(Texture[] Textures)
		{
			this.Textures = Textures;
		}

		public BoneCombination[] GetBones()
		{
			return(Bones);
		}

		public void SetBones(BoneCombination[] Bones)
		{
			this.Bones = Bones;
		}

		public ModelFrame[] GetFrames()
		{
			return(FrameMatrices);
		}

		public void SetFrames(ModelFrame[] FrameMatrices)
		{
			this.FrameMatrices = FrameMatrices;
		}

		public override Frame CreateFrame(String Name)
		{
			ModelFrame NewFrame = new ModelFrame();
			NewFrame.Name = name;
			NewFrame.TransformationMatrix = Matrix.Identity;
			NewFrame.CombinedTransformationMatrix = Matrix.Identity;

			return(NewFrame);
		}
	}
}
