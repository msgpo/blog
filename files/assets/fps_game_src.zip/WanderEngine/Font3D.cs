using System;
using System.Drawing;
using System.Text;

//OpenGL
using Tao.OpenGl;
using Tao.Platform.Windows;

namespace WanderEngine
{
	/// <summary>
	/// Summary description for Font3D.
	/// </summary>
	public class Font3D : IDisposable
	{
		private int Base = 0;
		private Texture FontTexture = null;
		private float ScreenWidth = 0.0f, ScreenHeight = 0.0f;
		
		public Font3D(SimpleOpenGlControl GlControl, String FontImage)
		{			
			//Load the texture
			FontTexture = new Texture(FontImage);

			//Generate display lists
			Base = Gl.glGenLists(256);

			ScreenWidth = GlControl.Width;
			ScreenHeight = GlControl.Height;

			//Build font
			float CharX = 0.0f, CharY = 1.0f;
			Gl.glBindTexture(Gl.GL_TEXTURE_2D, FontTexture.TextureID);

			for (int i=0; i<256; i++)
			{
				Gl.glNewList(Base + i, Gl.GL_COMPILE);
				Gl.glBegin(Gl.GL_QUADS);
				
				Gl.glTexCoord2f(CharX, CharY - 0.0625f);
				Gl.glVertex2d(0, 0);

				Gl.glTexCoord2f(CharX + 0.0625f, CharY - 0.0625f);
				Gl.glVertex2d(8, 0);

				Gl.glTexCoord2f(CharX + 0.0625f, CharY);
				Gl.glVertex2d(8, 8);

				Gl.glTexCoord2f(CharX, CharY);
				Gl.glVertex2d(0, 8);

				Gl.glEnd();
				Gl.glTranslated(5, 0, 0);
				Gl.glEndList();

				//Advance character position
				CharX += 0.0625f;

				if (CharX >= 1.0f)
				{
					CharX = 0.0f;
					CharY -= 0.0625f;
				}
			}
		}

		public void Render(float X, float Y, float Z, String Text)
		{			
			//Billboard
			Gl.glPushMatrix();

			//Move to text position
			Gl.glTranslatef(X, Y, Z);

			float[] ModelView = new float[16];
			float[] TempMatrix = new float[16];
			Gl.glGetFloatv(Gl.GL_MODELVIEW_MATRIX, ModelView);

			TempMatrix[0] = ModelView[0];
			TempMatrix[1] = ModelView[4];
			TempMatrix[2] = ModelView[8];
			TempMatrix[3] = 0.0f;
			TempMatrix[4] = ModelView[1];
			TempMatrix[5] = ModelView[5];
			TempMatrix[6] = ModelView[9];
			TempMatrix[7] = 0.0f;
			TempMatrix[8] = ModelView[2];
			TempMatrix[9] = ModelView[6];
			TempMatrix[10] = ModelView[10];
			TempMatrix[11] = 0.0f;
			TempMatrix[12] = 0.0f;
			TempMatrix[13] = 0.0f;
			TempMatrix[14] = 0.0f;
			TempMatrix[15] = 1.0f;

			Gl.glMultMatrixf(TempMatrix);
			
			Gl.glBindTexture(Gl.GL_TEXTURE_2D, FontTexture.TextureID);

			//Set state
			Gl.glEnable(Gl.GL_BLEND);
			Gl.glBlendFunc(Gl.GL_SRC_ALPHA, Gl.GL_ONE);

			Gl.glDisable(Gl.GL_CULL_FACE);

			//Center text
			Gl.glTranslatef((Text.Length * -4.0f), 0.0f, (Text.Length * -4.0f));

			//Render
			Gl.glListBase( (Base - 32) + 128 );
			Gl.glCallLists(Text.Length, Gl.GL_UNSIGNED_BYTE, Encoding.ASCII.GetBytes(Text));

			//Restore state
			Gl.glEnable(Gl.GL_CULL_FACE);
			Gl.glDisable(Gl.GL_BLEND);

			//Billboard
			Gl.glPopMatrix();
		}

		#region IDisposable Members

		public void Dispose()
		{
			//Delete display lists
			Gl.glDeleteLists(Base, 256);
		}

		#endregion
	}
}
