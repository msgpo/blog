using System;

namespace WanderEngine
{
	/// <summary>
	/// Summary description for CommandSet.
	/// </summary>
	public class CommandSet
	{
		public Vector3 PlayerMovement = new Vector3();
		public Vector2 PlayerLook = new Vector2();

		public Vector3 BoundMin = new Vector3(-20.0f, -40.0f, -20.0f);
		public float[] Min = new float[] { -20.0f, 40.0f, -20.0f };
		public Vector3 BoundMax = new Vector3(20.0f, 5.0f, 20.0f);
		public float[] Max = new float[] { 20.0f, 5.0f, 20.0f };

		public Vector3 Step = new Vector3(0.0f, 15.0f, 0.0f);
		public Vector3 MaxHeight = new Vector3(0.0f, 10000.0f, 0.0f);

		public CommandSet()
		{
			//Do nothing
		}
	}
}
