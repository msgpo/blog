using System;
using System.IO;
using System.Text;
using System.Drawing;

//OpenGL
using Tao.OpenGl;
using Tao.Platform.Windows;

namespace WanderEngine
{
	/// <summary>
	/// Summary description for MD2Model.
	/// </summary>
	
	#region MD2 Classes

	public class MD2Header
	{
		public int Identity;
		public int Version;
		public int SkinWidth;
		public int SkinHeight;
		public int FrameSize;
		public int NumSkins;
		public int NumPoints;
		public int NumTextureCoords;
		public int NumTriangles;
		public int NumGLCommands;
		public int NumFrames;
		public int SkinsOffset;
		public int TextureCoordsOffset;
		public int TrianglesOffset;
		public int FramesOffset;
		public int GLCommandsOffset;
		public int EndOffset;

		public MD2Header()
		{
			//Do nothing
		}

		public MD2Header(byte[] HeaderBytes)
		{
			BinaryReader Reader = new BinaryReader( new MemoryStream(HeaderBytes) );
			
			Identity = Reader.ReadInt32();
			Version = Reader.ReadInt32();

			if (Version != 8)
			{
				throw new Exception("Must be a version 8 MD2 model");
			}

			SkinWidth = Reader.ReadInt32();
			SkinHeight = Reader.ReadInt32();
			FrameSize = Reader.ReadInt32();
			NumSkins = Reader.ReadInt32();
			NumPoints = Reader.ReadInt32();
			NumTextureCoords = Reader.ReadInt32();
			NumTriangles = Reader.ReadInt32();
			NumGLCommands = Reader.ReadInt32();
			NumFrames = Reader.ReadInt32();
			SkinsOffset = Reader.ReadInt32();
			TextureCoordsOffset = Reader.ReadInt32();
			TrianglesOffset = Reader.ReadInt32();
			FramesOffset = Reader.ReadInt32();
			GLCommandsOffset = Reader.ReadInt32();
			EndOffset = Reader.ReadInt32();

			Reader.Close();
		}
	}

	public class MD2Face
	{
		public short[] VertexIndices = new short[3];
		public short[] TextureIndices = new short[3];

		public static readonly int SizeInBytes = 12;

		public MD2Face()
		{
			//Do nothing
		}
	}

	public class MD2FramePoint
	{
		public byte[] ScaledVertex = new byte[3];
		public byte LightNormalIndex;

		public MD2FramePoint()
		{
			//Do nothing
		}
	}

	public class MD2Frame
	{
		public Vector3 Scale = new Vector3();
		public Vector3 Translate = new Vector3();
		public String Name = "";
		public MD2FramePoint[] FramePoints;

		public MD2Frame()
		{
			//Do nothing
		}
	}

	public enum AnimationState
	{
		Stand, Run, Attack, PainA, PainB, PainC,
		Jump, Flip, Salute, FallBack, Wave, Point,
		CrouchStand, CrouchWalk, CrouchAttack, CrouchPain, CrouchDeath,
		DeathFallBack, DeathFallFoward, DeathFallBackSlow, Boom
	}

	#endregion

	public class MD2Model
	{
		#region Class Variables

		//Constants
		private static readonly int SkinNameSizeInBytes = 64;
		private static readonly int HeaderSizeInBytes = 68;

		//Header
		private MD2Header Header = null;

		//Skins
		private int NumSkins = 0;
		private String[] Skins = null;

		//Faces
		private int NumFaces = 0;
		private MD2Face[] Faces = null;
		
		//Frames
		private int NumFrames = 0;
		private int NumFramePoints = 0;
		private int PointsPerFrame = 0;
		private MD2Frame[] Frames = null;
		
		//Textures
		private Texture ModelTexture;
		
		//Texture coordinates
		private int NumTextureCoords = 0;
		private Vector2[] TextureCoords = null;

		//Vertices
		private int NumVertices = 0;
		private Vector3[] Vertices = null;

		//Animation
		private int CurrentFrame = 0, NextFrame = 0;
		private float Interpolation = 0.0f;
		private AnimationState m_ModelState = AnimationState.Stand;
		private int AnimStartFrame = 0, AnimEndFrame = 39;
		private float AnimPercent = 4.0f;

		//Other
		public Vector3 Position = new Vector3();
		public float Yaw = 0.0f;
		private Vector3 m_BoundMin = new Vector3();
		private Vector3 m_BoundMax = new Vector3();
		private Vector3 m_Center = new Vector3();
		
		//Properties
		public Vector3 BoundMin
		{
			get { return(m_BoundMin); }
		}

		public Vector3 BoundMax
		{
			get { return(m_BoundMax); }
		}

		public Vector3 Center
		{
			get { return(m_Center); }
		}

		public AnimationState ModelState
		{
			get { return(m_ModelState); }
			set { SetModelState(value); }
		}

		#endregion
		
		public MD2Model(String FileName, String TextureFileName)
		{
			//Load the model into memory
			LoadModel(FileName, TextureFileName);
		}

		#region Animation Procedures

		private void SetModelState(AnimationState NewState)
		{
			m_ModelState = NewState;

			switch(NewState)
			{
				case AnimationState.Stand:
					AnimStartFrame = 0;
					AnimEndFrame = 30;
					AnimPercent = 4.0f;
					break;

				case AnimationState.Run:
					AnimStartFrame = 40;
					AnimEndFrame = 45;
					AnimPercent = 4.0f;
					break;

				case AnimationState.Attack:
					AnimStartFrame = 46;
					AnimEndFrame = 53;
					AnimPercent = 4.0f;
					break;

				case AnimationState.PainA:
					AnimStartFrame = 54;
					AnimEndFrame = 57;
					AnimPercent = 4.0f;
					break;

				case AnimationState.PainB:
					AnimStartFrame = 58;
					AnimEndFrame = 61;
					AnimPercent = 4.0f;
					break;

				case AnimationState.PainC:
					AnimStartFrame = 62;
					AnimEndFrame = 65;
					AnimPercent = 4.0f;
					break;

				case AnimationState.Jump:
					AnimStartFrame = 66;
					AnimEndFrame = 71;
					AnimPercent = 4.0f;
					break;

				case AnimationState.Flip:
					AnimStartFrame = 72;
					AnimEndFrame = 83;
					AnimPercent = 4.0f;
					break;

				case AnimationState.Salute:
					AnimStartFrame = 84;
					AnimEndFrame = 94;
					AnimPercent = 4.0f;
					break;

				case AnimationState.FallBack:
					AnimStartFrame = 95;
					AnimEndFrame = 111;
					AnimPercent = 4.0f;
					break;

				case AnimationState.Wave:
					AnimStartFrame = 112;
					AnimEndFrame = 122;
					AnimPercent = 4.0f;
					break;

				case AnimationState.Point:
					AnimStartFrame = 123;
					AnimEndFrame = 134;
					AnimPercent = 4.0f;
					break;

				case AnimationState.CrouchStand:
					AnimStartFrame = 135;
					AnimEndFrame = 153;
					AnimPercent = 4.0f;
					break;

				case AnimationState.CrouchWalk:
					AnimStartFrame = 154;
					AnimEndFrame = 159;
					AnimPercent = 4.0f;
					break;

				case AnimationState.CrouchAttack:
					AnimStartFrame = 160;
					AnimEndFrame = 168;
					AnimPercent = 4.0f;
					break;

				case AnimationState.CrouchPain:
					AnimStartFrame = 169;
					AnimEndFrame = 172;
					AnimPercent = 4.0f;
					break;

				case AnimationState.CrouchDeath:
					AnimStartFrame = 173;
					AnimEndFrame = 177;
					AnimPercent = 4.0f;
					break;

				case AnimationState.DeathFallBack:
					AnimStartFrame = 178;
					AnimEndFrame = 183;
					AnimPercent = 4.0f;
					break;

				case AnimationState.DeathFallFoward:
					AnimStartFrame = 184;
					AnimEndFrame = 189;
					AnimPercent = 4.0f;
					break;

				case AnimationState.DeathFallBackSlow:
					AnimStartFrame = 190;
					AnimEndFrame = 197;
					AnimPercent = 4.0f;
					break;

				case AnimationState.Boom:
					AnimStartFrame = 198;
					AnimEndFrame = 198;
					AnimPercent = 4.0f;
					break;
			}
		}

		public void Update(float TimeElapsed)
		{
			Animate(AnimStartFrame, AnimEndFrame, AnimPercent * TimeElapsed);
		}

		#endregion

		#region Render Routines

		public void Animate(int StartFrame, int EndFrame, float Percent)
		{
			//Move to the start of the animation
			if (StartFrame > CurrentFrame)
			{
				CurrentFrame = StartFrame;
			}

			//Reset interpolation
			if (Interpolation > 1.0f)
			{
				Interpolation = 0.0f;
				CurrentFrame++;

				//Wrap animation around
				if (CurrentFrame >= EndFrame)
				{
					CurrentFrame = StartFrame;
				}

				NextFrame = CurrentFrame + 1;

				if (NextFrame >= EndFrame)
				{
					NextFrame = StartFrame;
				}
			}

			//Calculate frame indices
			int CurrentFrameIndex = CurrentFrame * Header.NumPoints;
			int NextFrameIndex = NextFrame * Header.NumPoints;

			//Move to model position
			Gl.glPushMatrix();
			Gl.glTranslatef(Position.X, Position.Y, Position.Z);
			Gl.glRotatef(Yaw, 0.0f, 1.0f, 0.0f);

			Gl.glCullFace(Gl.GL_BACK);
			Gl.glBindTexture(Gl.GL_TEXTURE_2D, ModelTexture.TextureID);
			Gl.glBegin(Gl.GL_TRIANGLES);

			for (int i=0; i<NumFaces; i++)
			{
				//Extract vertices								
				Vector3 V1_1 = Vertices[ CurrentFrameIndex + Faces[i].VertexIndices[0] ];
				Vector3 V1_2 = Vertices[ CurrentFrameIndex + Faces[i].VertexIndices[2] ];
				Vector3 V1_3 = Vertices[ CurrentFrameIndex + Faces[i].VertexIndices[1] ];

				Vector3 V2_1 = Vertices[ NextFrameIndex + Faces[i].VertexIndices[0] ];
				Vector3 V2_2 = Vertices[ NextFrameIndex + Faces[i].VertexIndices[2] ];
				Vector3 V2_3 = Vertices[ NextFrameIndex + Faces[i].VertexIndices[1] ];

				//Generate interpolated vertices
				Vector3 VI_1 = new Vector3();
				VI_1.X = V1_1.X + (Interpolation * (V2_1.X - V1_1.X));
				VI_1.Y = V1_1.Y + (Interpolation * (V2_1.Y - V1_1.Y));
				VI_1.Z = V1_1.Z + (Interpolation * (V2_1.Z - V1_1.Z));

				Gl.glTexCoord2f(TextureCoords[ Faces[i].TextureIndices[0] ].X,
					TextureCoords[ Faces[i].TextureIndices[0] ].Y);
				Gl.glVertex3f(VI_1.X, VI_1.Y, VI_1.Z);
				
				Vector3 VI_2 = new Vector3();
				VI_2.X = V1_2.X + (Interpolation * (V2_2.X - V1_2.X));
				VI_2.Y = V1_2.Y + (Interpolation * (V2_2.Y - V1_2.Y));
				VI_2.Z = V1_2.Z + (Interpolation * (V2_2.Z - V1_2.Z));

				Gl.glTexCoord2f(TextureCoords[ Faces[i].TextureIndices[2] ].X,
					TextureCoords[ Faces[i].TextureIndices[2] ].Y);
				Gl.glVertex3f(VI_2.X, VI_2.Y, VI_2.Z);

				Vector3 VI_3 = new Vector3();
				VI_3.X = V1_3.X + (Interpolation * (V2_3.X - V1_3.X));
				VI_3.Y = V1_3.Y + (Interpolation * (V2_3.Y - V1_3.Y));
				VI_3.Z = V1_3.Z + (Interpolation * (V2_3.Z - V1_3.Z));

				Gl.glTexCoord2f(TextureCoords[ Faces[i].TextureIndices[1] ].X,
					TextureCoords[ Faces[i].TextureIndices[1] ].Y);
				Gl.glVertex3f(VI_3.X, VI_3.Y, VI_3.Z);
			}

			Gl.glEnd();

			Gl.glCullFace(Gl.GL_FRONT);

			//Restore world matrix
			Gl.glPopMatrix();
			
			//Advance animation
			Interpolation += Percent;
		}

		#endregion

		#region Loading Routines

		private void LoadModel(String FileName, String TextureFileName)
		{	
			BinaryReader InputFile = new BinaryReader( new FileStream(FileName, FileMode.Open, FileAccess.Read) );

			//======
			//Header
			//======
			byte[] HeaderBytes = InputFile.ReadBytes(MD2Model.HeaderSizeInBytes);
			Header = new MD2Header(HeaderBytes);

			//==============
			//Allocate lists
			//==============

			//Skins
			NumSkins = Header.NumSkins;
			Skins = new String[NumSkins];

			//Faces
			NumFaces = Header.NumTriangles;
			Faces = new MD2Face[NumFaces];
			
			//Frames
			NumFrames = Header.NumFrames;
			NumFramePoints = Header.NumPoints;
			PointsPerFrame = Header.NumTriangles * 3;
			Frames = new MD2Frame[NumFrames];
						
			//Texture coordinates
			NumTextureCoords = Header.NumTextureCoords;
			TextureCoords = new Vector2[NumTextureCoords];

			//Vertices
			NumVertices = Header.NumFrames * Header.NumPoints;
			Vertices = new Vector3[NumVertices];

			//=====
			//Skins
			//=====
			InputFile.BaseStream.Seek(Header.SkinsOffset, SeekOrigin.Begin);
			for (int i=0; i<NumSkins; i++)
			{
				byte[] SkinBytes = InputFile.ReadBytes(MD2Model.SkinNameSizeInBytes);								
				Skins[i] = ParseString(SkinBytes);
			}

			//========
			//Textures
			//========
			ModelTexture = new Texture(TextureFileName);
									
			//===================
			//Texture Coordinates
			//===================
			InputFile.BaseStream.Seek(Header.TextureCoordsOffset, SeekOrigin.Begin);
			for (int i=0; i<NumTextureCoords; i++)
			{
				TextureCoords[i] = new Vector2();

				short S = InputFile.ReadInt16();
				short T = InputFile.ReadInt16();

				//Read 2 shorts (flip Y texture coordinate)
				TextureCoords[i].X = (float)S / (float)Header.SkinWidth;
				TextureCoords[i].Y = -((float)T / (float)Header.SkinHeight);
			}

			//=====
			//Faces
			//=====
			InputFile.BaseStream.Seek(Header.TrianglesOffset, SeekOrigin.Begin);
			for (int i=0; i<NumFaces; i++)
			{
				byte[] InputData = InputFile.ReadBytes(MD2Face.SizeInBytes);
				BinaryReader Reader = new BinaryReader( new MemoryStream(InputData) );

				Faces[i] = new MD2Face();

				//Parse 6 shorts
				Faces[i].VertexIndices[0] = Reader.ReadInt16();
				Faces[i].VertexIndices[1] = Reader.ReadInt16();
				Faces[i].VertexIndices[2] = Reader.ReadInt16();
				Faces[i].TextureIndices[0] = Reader.ReadInt16();
				Faces[i].TextureIndices[1] = Reader.ReadInt16();
				Faces[i].TextureIndices[2] = Reader.ReadInt16();
			}

			//======
			//Frames
			//======
			InputFile.BaseStream.Seek(Header.FramesOffset, SeekOrigin.Begin);
			for (int i=0; i<NumFrames; i++)
			{
				Frames[i] = new MD2Frame();

				//Allocate frame points
				Frames[i].FramePoints = new MD2FramePoint[Header.NumPoints];

				//Parse out 3 floats
				Frames[i].Scale.X = InputFile.ReadSingle();
				Frames[i].Scale.Y = InputFile.ReadSingle();
				Frames[i].Scale.Z = InputFile.ReadSingle();

				//Parse out 3 floats
				Frames[i].Translate.X = InputFile.ReadSingle();
				Frames[i].Translate.Y = InputFile.ReadSingle();
				Frames[i].Translate.Z = InputFile.ReadSingle();

				//Parse out a 16-byte string
				Frames[i].Name = ParseString( InputFile.ReadBytes(16) );
				
				//Parse out 4-byte frame points
				for (int j=0; j<NumFramePoints; j++)
				{
					//Copy frame point
					Frames[i].FramePoints[j] = new MD2FramePoint();
					Frames[i].FramePoints[j].ScaledVertex[0] = InputFile.ReadByte();
					Frames[i].FramePoints[j].ScaledVertex[1] = InputFile.ReadByte();
					Frames[i].FramePoints[j].ScaledVertex[2] = InputFile.ReadByte();
					Frames[i].FramePoints[j].LightNormalIndex = InputFile.ReadByte();
				}
			}

			//========
            //Vertices
			//========
			int PointIndex = 0;
			for (int i=0; i<NumFrames; i++)
			{
				for (int j=0; j<NumFramePoints; j++)
				{
					Vertices[PointIndex] = new Vector3();

					Vertices[PointIndex].X =  Frames[i].FramePoints[j].ScaledVertex[0] *
						Frames[i].Scale.X + Frames[i].Translate.X;

					Vertices[PointIndex].Z = -(Frames[i].FramePoints[j].ScaledVertex[1] *
						Frames[i].Scale.Y + Frames[i].Translate.Y);

					Vertices[PointIndex].Y = Frames[i].FramePoints[j].ScaledVertex[2] *
						Frames[i].Scale.Z + Frames[i].Translate.Z;

					//Calculate bounding box
					if (Vertices[PointIndex].X < m_BoundMin.X)
					{
						m_BoundMin.X = Vertices[PointIndex].X;
					}

					if (Vertices[PointIndex].Y < m_BoundMin.Y)
					{
						m_BoundMin.Y = Vertices[PointIndex].Y;
					}

					if (Vertices[PointIndex].Z < m_BoundMin.Z)
					{
						m_BoundMin.Z = Vertices[PointIndex].Z;
					}

					if (Vertices[PointIndex].X > m_BoundMax.X)
					{
						m_BoundMax.X = Vertices[PointIndex].X;
					}

					if (Vertices[PointIndex].Y > m_BoundMax.Y)
					{
						m_BoundMax.Y = Vertices[PointIndex].Y;
					}

					if (Vertices[PointIndex].Z > m_BoundMax.Z)
					{
						m_BoundMax.Z = Vertices[PointIndex].Z;
					}
						
					//Next point
					PointIndex++;
				}
			}

			//Calculate center
			m_Center.X = (Math.Abs(BoundMax.X) - Math.Abs(BoundMin.X)) / 2;
			m_Center.Y = (Math.Abs(BoundMax.Y) - Math.Abs(BoundMin.Y)) / 2;
			m_Center.Z = (Math.Abs(BoundMax.Z) - Math.Abs(BoundMin.Z)) / 2;

			//Close input file
			InputFile.Close();
		}

		private String ParseString(byte[] StringData)
		{
			String ReturnString = "";

			for (int i=0; i<StringData.Length; i++)
			{
				if (StringData[i] != '\0')
				{
					ReturnString += Convert.ToChar(StringData[i]);
				}
			}

			return(ReturnString);
		}

		#endregion
	}
}
