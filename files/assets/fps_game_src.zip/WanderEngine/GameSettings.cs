using System;

namespace WanderEngine
{
	/// <summary>
	/// Summary description for GameSettings.
	/// </summary>
	public abstract class GameSettings
	{
		public static float MoveSpeed = 300.0f;
		public static float StrafeSpeed = 300.0f;
		public static float LookUpDownSpeed = 12.0f;
		public static float LookLeftRightSpeed = 15.0f;
		public static float PlayerBound = 15.0f;
		public static float PlayerFrontBackBound = 1.0f;
		
		public GameSettings()
		{
			//
			// TODO: Add constructor logic here
			//
		}
	}
}
