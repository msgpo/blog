using System;

//DirectX
using Microsoft.DirectX;

//DirectInput
using Microsoft.DirectX.DirectInput;
using DirectInput = Microsoft.DirectX.DirectInput;

namespace WanderEngine
{
	/// <summary>
	/// Summary description for ControlConfig.
	/// </summary>
	public class ControlConfig
	{
		public Key MoveForward = Key.UpArrow;
		public Key MoveBack = Key.DownArrow;
		public Key LeftStrafe = Key.LeftArrow;
		public Key RightStrafe = Key.RightArrow;

		public float MoveSpeed = 200.0f;

		public bool InvertMouse = false;
		public float MouseSpeedHorz = 4.0f;
		public float MouseSpeedVert = 3.0f;

		public ControlConfig()
		{
			//Do nothing
		}
	}
}
