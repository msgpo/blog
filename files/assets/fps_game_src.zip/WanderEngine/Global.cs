using System;

namespace WanderEngine
{
	/// <summary>
	/// Summary description for Global.
	/// </summary>
	public abstract class Global
	{
		//Constants
		public const float DegreeToRadian = (2 * (float)Math.PI) / 360;
		
		public static float SinDeg(float Angle)
		{
			return( (float)Math.Sin(Angle * DegreeToRadian) );
		}

		public static float CosDeg(float Angle)
		{
			return( (float)Math.Cos(Angle * DegreeToRadian) );
		}

		public static float CapAngle(float Angle)
		{
			if (Angle > 360.0f)
			{
				Angle -= 360.0f;
			}

			if (Angle < 0.0f)
			{
				Angle += 360.0f;
			}

			return(Angle);
		}
	}
}
