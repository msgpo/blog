using System;

//DirectX
using Microsoft.DirectX;

//Direct3D
using Microsoft.DirectX.Direct3D;
using Direct3D = Microsoft.DirectX.Direct3D;

namespace WanderEngine
{
	/// <summary>
	/// Summary description for EngineSettings.
	/// </summary>
	public class EngineSettings
	{
		public Cull CullMode = Cull.None;
		public TextureFilter MipMapTexFilter = TextureFilter.None;		
		public TextureFilter MagTexFilter = TextureFilter.None;
		public TextureFilter MinTexFilter = TextureFilter.None;

		public EngineSettings()
		{
			//
			// TODO: Add constructor logic here
			//
		}
	}
}
