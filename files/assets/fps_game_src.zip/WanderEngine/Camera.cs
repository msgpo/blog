using System;

//OpenGL
using Tao.OpenGl;
using Tao.Platform.Windows;

namespace WanderEngine
{
	/// <summary>
	/// Summary description for Camera.
	/// </summary>
	public class Camera
	{
		//Vectors
		public Vector3 Position = new Vector3(0.0f, 0.0f, 0.0f);
		public Vector3 View = new Vector3(0.0f, 0.0f, 1.0f);
		public Vector3 UpVector = new Vector3(0.0f, 1.0f, 0.0f);
		public Vector3 Strafe = new Vector3();

		//State variables
		public float Pitch = 0.0f, Yaw = 0.0f;
						
		public Camera()
		{
			//Set default view
			SetMouseView(0.0f, 0.0f);
		}

		public Camera(Vector3 Position, Vector3 View, Vector3 UpVector)
		{
			//Copy values
			this.Position = Position;
			this.View = View;
			this.UpVector = UpVector;
		}

		public void SetMouseView(float Dx, float Dy)
		{
			//Update view angles
			Pitch += Dy;
			Yaw -= Dx;

			if (Pitch > 90.0f)
			{
				Pitch = 90.0f;
			}

			if (Pitch < -90.0f)
			{
				Pitch = -90.0f;
			}

			//Calcuate new view
			View.X = Position.X + Global.SinDeg(Yaw);
			View.Y = Position.Y + Global.SinDeg(Pitch);
			View.Z = Position.Z - Global.CosDeg(Yaw);
		}

		public void StrafeCamera(float Speed)
		{
			float Dx = Strafe.X * Speed;
			float Dz = Strafe.Z * Speed;

			//Update position and view
			Position.X += Dx;
			Position.Z += Dz;

			View.X += Dx;
			View.Z += Dz;
		}

		public void MoveCamera(float Speed)
		{
			//Calculate view vector
			Vector3 ViewVector = View - Position;
			ViewVector.Normalize();

			float Dx = ViewVector.X * Speed;
			//float Dy = ViewVector.Y * Speed;
			float Dz = ViewVector.Z * Speed;

			//Update position and view
			Position.X += Dx;
			//Position.Y += Dy;
			Position.Z += Dz;

			View.X += Dx;
			//View.Y += Dy;
			View.Z += Dz;
		}

		public void MoveCameraTo(Vector3 NewPos)
		{
			View = View + NewPos - Position;
			Position.X = NewPos.X;
			Position.Y = NewPos.Y;
			Position.Z = NewPos.Z;
		}

		public void MoveCameraUpDown(float Speed)
		{
			Position.Y += Speed;
			View.Y += Speed;
		}

		public Vector3 ProjectPosition(float FrontBack, float LeftRight)
		{			
			Vector3 NewPos = new Vector3(Position.X, Position.Y, Position.Z);

			if (FrontBack > 0.0f)
			{
				float FrontBackAngle = Global.CapAngle(90 - Yaw);
				FrontBack = Math.Abs(FrontBack);

				NewPos.X += Global.CosDeg(FrontBackAngle) * FrontBack;
				NewPos.Z += -Global.SinDeg(FrontBackAngle) * FrontBack;
			}
			else if (FrontBack < 0.0f)
			{
				float FrontBackAngle = Global.CapAngle(90 - Yaw);
				FrontBack = Math.Abs(FrontBack);

				NewPos.X -= Global.CosDeg(FrontBackAngle) * FrontBack;
				NewPos.Z += Global.SinDeg(FrontBackAngle) * FrontBack;
			}

			if (LeftRight > 0.0f)
			{
				float LeftRightAngle = Global.CapAngle(-Yaw);
				LeftRight = Math.Abs(LeftRight);

				NewPos.X += Global.CosDeg(LeftRightAngle) * LeftRight;
				NewPos.Z += -Global.SinDeg(LeftRightAngle) * LeftRight;
			}
			else if (LeftRight < 0.0f)
			{
				float LeftRightAngle = Global.CapAngle(-Yaw);
				LeftRight = Math.Abs(LeftRight);

				NewPos.X -= Global.CosDeg(LeftRightAngle) * LeftRight;
				NewPos.Z += Global.SinDeg(LeftRightAngle) * LeftRight;
			}

			return(NewPos);
		}

		public static Vector3 ProjectVector(Vector3 SourceVector,
			float FrontBack, float LeftRight, float Yaw)
		{			
			Vector3 NewPos = new Vector3(SourceVector.X, SourceVector.Y, SourceVector.Z);

			if (FrontBack > 0.0f)
			{
				float FrontBackAngle = Global.CapAngle(90 - Yaw);
				FrontBack = Math.Abs(FrontBack);

				NewPos.X += Global.CosDeg(FrontBackAngle) * FrontBack;
				NewPos.Z += -Global.SinDeg(FrontBackAngle) * FrontBack;
			}
			else if (FrontBack < 0.0f)
			{
				float FrontBackAngle = Global.CapAngle(90 - Yaw);
				FrontBack = Math.Abs(FrontBack);

				NewPos.X -= Global.CosDeg(FrontBackAngle) * FrontBack;
				NewPos.Z += Global.SinDeg(FrontBackAngle) * FrontBack;
			}

			if (LeftRight > 0.0f)
			{
				float LeftRightAngle = Global.CapAngle(-Yaw);
				LeftRight = Math.Abs(LeftRight);

				NewPos.X += Global.CosDeg(LeftRightAngle) * LeftRight;
				NewPos.Z += -Global.SinDeg(LeftRightAngle) * LeftRight;
			}
			else if (LeftRight < 0.0f)
			{
				float LeftRightAngle = Global.CapAngle(-Yaw);
				LeftRight = Math.Abs(LeftRight);

				NewPos.X -= Global.CosDeg(LeftRightAngle) * LeftRight;
				NewPos.Z += Global.SinDeg(LeftRightAngle) * LeftRight;
			}

			return(NewPos);
		}

		public void UpdateView()
		{
			//Update strafe vector
			Vector3 CrossVector = Vector3.Cross( View - Position, UpVector );
			Strafe = Vector3.Normalize(CrossVector);

			//Update camera
			Glu.gluLookAt(Position.X, Position.Y, Position.Z, View.X, View.Y,
				View.Z, UpVector.X, UpVector.Y, UpVector.Z);
		}
	}
}
