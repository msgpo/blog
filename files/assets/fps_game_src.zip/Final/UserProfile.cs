using System;
using System.IO;
using System.Xml;

namespace Final
{
	/// <summary>
	/// Summary description for UserProfile.
	/// </summary>
	public class UserProfile
	{
		public String Name = "";
		public String ModelName = "";

		public UserProfile()
		{
			//Do nothing
		}

		public UserProfile(String Name, String ModelName)
		{
			//Copy values
			this.Name = Name;
			this.ModelName = ModelName;
		}

		public override string ToString()
		{
			return(Name);
		}

	}
}
