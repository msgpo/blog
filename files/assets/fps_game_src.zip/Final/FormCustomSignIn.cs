using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.IO;
using System.Net;
using System.Xml;

namespace Final
{
	/// <summary>
	/// Summary description for FormCustomSignIn.
	/// </summary>
	public class FormCustomSignIn : System.Windows.Forms.Form
	{
		private System.Windows.Forms.TextBox TextBoxName;
		private System.Windows.Forms.Label LabelName;
		private System.Windows.Forms.Label LabelServerAddress;
		private System.Windows.Forms.TextBox TextBoxServerAddress;
		private System.Windows.Forms.Button ButtonOK;
		private System.Windows.Forms.Button ButtonCancel;
		private System.Windows.Forms.ImageList ImageListPictures;
		private System.Windows.Forms.PictureBox PictureBoxModels;
		private System.Windows.Forms.Button ButtonPrevious;
		private System.Windows.Forms.Button ButtonNext;
		private System.ComponentModel.IContainer components;
		private System.Windows.Forms.CheckBox CheckBoxServer;
		private System.Windows.Forms.CheckBox CheckBoxVoice;

		//Return variables
		public UserProfile ReturnProfile = null;
		public IPAddress ServerAddress = null;
		public bool VoiceEnabled = false;
				
		//Internal state variables
		private ArrayList Images = new ArrayList();
		private Hashtable ImageModelHash = new Hashtable();
		
		private int PictureIndex = 0;
		private String ModelName = "";

		private readonly String ConfigPath = Application.StartupPath + @"\profile.xml";

		public FormCustomSignIn()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(FormCustomSignIn));
			this.TextBoxName = new System.Windows.Forms.TextBox();
			this.LabelName = new System.Windows.Forms.Label();
			this.LabelServerAddress = new System.Windows.Forms.Label();
			this.TextBoxServerAddress = new System.Windows.Forms.TextBox();
			this.ButtonOK = new System.Windows.Forms.Button();
			this.ButtonCancel = new System.Windows.Forms.Button();
			this.ImageListPictures = new System.Windows.Forms.ImageList(this.components);
			this.PictureBoxModels = new System.Windows.Forms.PictureBox();
			this.ButtonPrevious = new System.Windows.Forms.Button();
			this.ButtonNext = new System.Windows.Forms.Button();
			this.CheckBoxServer = new System.Windows.Forms.CheckBox();
			this.CheckBoxVoice = new System.Windows.Forms.CheckBox();
			this.SuspendLayout();
			// 
			// TextBoxName
			// 
			this.TextBoxName.Location = new System.Drawing.Point(8, 40);
			this.TextBoxName.Name = "TextBoxName";
			this.TextBoxName.Size = new System.Drawing.Size(176, 20);
			this.TextBoxName.TabIndex = 0;
			this.TextBoxName.Text = "";
			// 
			// LabelName
			// 
			this.LabelName.Location = new System.Drawing.Point(8, 16);
			this.LabelName.Name = "LabelName";
			this.LabelName.TabIndex = 4;
			this.LabelName.Text = "Name";
			// 
			// LabelServerAddress
			// 
			this.LabelServerAddress.Location = new System.Drawing.Point(8, 72);
			this.LabelServerAddress.Name = "LabelServerAddress";
			this.LabelServerAddress.TabIndex = 5;
			this.LabelServerAddress.Text = "Server Address";
			// 
			// TextBoxServerAddress
			// 
			this.TextBoxServerAddress.Location = new System.Drawing.Point(8, 96);
			this.TextBoxServerAddress.Name = "TextBoxServerAddress";
			this.TextBoxServerAddress.Size = new System.Drawing.Size(176, 20);
			this.TextBoxServerAddress.TabIndex = 1;
			this.TextBoxServerAddress.Text = "";
			// 
			// ButtonOK
			// 
			this.ButtonOK.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.ButtonOK.Location = new System.Drawing.Point(208, 96);
			this.ButtonOK.Name = "ButtonOK";
			this.ButtonOK.TabIndex = 2;
			this.ButtonOK.Text = "&OK";
			this.ButtonOK.Click += new System.EventHandler(this.ButtonOK_Click);
			// 
			// ButtonCancel
			// 
			this.ButtonCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
			this.ButtonCancel.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.ButtonCancel.Location = new System.Drawing.Point(296, 96);
			this.ButtonCancel.Name = "ButtonCancel";
			this.ButtonCancel.TabIndex = 3;
			this.ButtonCancel.Text = "&Cancel";
			this.ButtonCancel.Click += new System.EventHandler(this.ButtonCancel_Click);
			// 
			// ImageListPictures
			// 
			this.ImageListPictures.ColorDepth = System.Windows.Forms.ColorDepth.Depth24Bit;
			this.ImageListPictures.ImageSize = new System.Drawing.Size(50, 100);
			this.ImageListPictures.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("ImageListPictures.ImageStream")));
			this.ImageListPictures.TransparentColor = System.Drawing.Color.Transparent;
			// 
			// PictureBoxModels
			// 
			this.PictureBoxModels.BackColor = System.Drawing.Color.Black;
			this.PictureBoxModels.Location = new System.Drawing.Point(8, 128);
			this.PictureBoxModels.Name = "PictureBoxModels";
			this.PictureBoxModels.Size = new System.Drawing.Size(358, 312);
			this.PictureBoxModels.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
			this.PictureBoxModels.TabIndex = 6;
			this.PictureBoxModels.TabStop = false;
			// 
			// ButtonPrevious
			// 
			this.ButtonPrevious.Enabled = false;
			this.ButtonPrevious.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.ButtonPrevious.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.ButtonPrevious.Location = new System.Drawing.Point(8, 448);
			this.ButtonPrevious.Name = "ButtonPrevious";
			this.ButtonPrevious.TabIndex = 7;
			this.ButtonPrevious.Text = "<<";
			this.ButtonPrevious.Click += new System.EventHandler(this.ButtonPrevious_Click);
			// 
			// ButtonNext
			// 
			this.ButtonNext.Enabled = false;
			this.ButtonNext.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.ButtonNext.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.ButtonNext.Location = new System.Drawing.Point(296, 448);
			this.ButtonNext.Name = "ButtonNext";
			this.ButtonNext.TabIndex = 8;
			this.ButtonNext.Text = ">>";
			this.ButtonNext.Click += new System.EventHandler(this.ButtonNext_Click);
			// 
			// CheckBoxServer
			// 
			this.CheckBoxServer.Checked = true;
			this.CheckBoxServer.CheckState = System.Windows.Forms.CheckState.Checked;
			this.CheckBoxServer.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.CheckBoxServer.Location = new System.Drawing.Point(208, 24);
			this.CheckBoxServer.Name = "CheckBoxServer";
			this.CheckBoxServer.Size = new System.Drawing.Size(160, 24);
			this.CheckBoxServer.TabIndex = 9;
			this.CheckBoxServer.Text = "Connect to a network server";
			this.CheckBoxServer.CheckedChanged += new System.EventHandler(this.CheckBoxServer_CheckedChanged);
			// 
			// CheckBoxVoice
			// 
			this.CheckBoxVoice.Enabled = false;
			this.CheckBoxVoice.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.CheckBoxVoice.Location = new System.Drawing.Point(208, 56);
			this.CheckBoxVoice.Name = "CheckBoxVoice";
			this.CheckBoxVoice.Size = new System.Drawing.Size(160, 24);
			this.CheckBoxVoice.TabIndex = 10;
			this.CheckBoxVoice.Text = "Enable voice chat";
			// 
			// FormCustomSignIn
			// 
			this.AcceptButton = this.ButtonOK;
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.CancelButton = this.ButtonCancel;
			this.ClientSize = new System.Drawing.Size(378, 480);
			this.Controls.Add(this.CheckBoxVoice);
			this.Controls.Add(this.CheckBoxServer);
			this.Controls.Add(this.ButtonPrevious);
			this.Controls.Add(this.ButtonNext);
			this.Controls.Add(this.PictureBoxModels);
			this.Controls.Add(this.ButtonCancel);
			this.Controls.Add(this.ButtonOK);
			this.Controls.Add(this.LabelServerAddress);
			this.Controls.Add(this.TextBoxServerAddress);
			this.Controls.Add(this.LabelName);
			this.Controls.Add(this.TextBoxName);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.MaximizeBox = false;
			this.MinimizeBox = false;
			this.Name = "FormCustomSignIn";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "Player sign in";
			this.Load += new System.EventHandler(this.FormCustomSignIn_Load);
			this.ResumeLayout(false);

		}
		#endregion

		private void LoadConfig(String FileName)
		{
			XmlTextReader Reader = new XmlTextReader( new FileStream(FileName, FileMode.Open) );

			while(Reader.Read())
			{
				switch(Reader.NodeType)
				{
					case XmlNodeType.Element:

					switch(Reader.Name)
					{
						case "serveraddress":
							TextBoxServerAddress.Text = Reader.ReadString();
							break;
							
						case "serverenabled":
							CheckBoxServer.Checked = bool.Parse(Reader.ReadString());
							break;

						case "name":
							TextBoxName.Text = Reader.ReadString();
							break;

						case "modelname":
							ModelName = Reader.ReadString();							
							break;

						case "voiceenabled":
							CheckBoxVoice.Checked = bool.Parse(Reader.ReadString());
							break;
					}

						break;
				}
			}

			Reader.Close();
		}

		private void SaveConfig(String FileName)
		{
			StreamWriter OutputFile = new StreamWriter( new FileStream(FileName, FileMode.Create) );

			//Write Xml
			OutputFile.WriteLine("<?xml version='1.0' ?>");
			OutputFile.WriteLine("<profile>");

			OutputFile.WriteLine("<serverenabled>" + CheckBoxServer.Checked.ToString() + "</serverenabled>");
			OutputFile.WriteLine("<name>" + TextBoxName.Text + "</name>");
			OutputFile.WriteLine("<modelname>" + ModelName + "</modelname>");
			OutputFile.WriteLine("<voiceenabled>" + CheckBoxVoice.Checked.ToString() + "</voiceenabled>");
			
			if (ServerAddress != null)
			{
				OutputFile.WriteLine("<serveraddress>" + ServerAddress.ToString() + "</serveraddress>");
			}
			else
			{
				OutputFile.WriteLine("<serveraddress/>");
			}

			OutputFile.WriteLine("</profile>");

			OutputFile.Close();
		}

		private void FormCustomSignIn_Load(object sender, System.EventArgs e)
		{
			//Load all model names
			DirectoryInfo ModelDir = new DirectoryInfo(Application.StartupPath + @"\models");

			if (ModelDir.Exists)
			{
				FileInfo[] ModelFiles = ModelDir.GetFiles("*.md2");

				foreach(FileInfo ModelFile in ModelFiles)
				{
					String RootName = ModelFile.Name.Substring( 0, ModelFile.Name.LastIndexOf(".") );

					FileInfo[] ModelPictures = ModelDir.GetFiles(RootName + "_i.*");

					//Use the first picture found
					if (ModelPictures.Length > 0)
					{
						try
						{
							Image MD2Pic = Image.FromFile(ModelPictures[0].FullName);

							//Add to lists
							Images.Add(MD2Pic);
							ImageModelHash[MD2Pic] = RootName;
						}
						catch
						{
							//Do nothing
						}
					}
				}
			}

			//Setup controls
			if (Images.Count > 0)
			{
				PictureBoxModels.Image = (Image)Images[0];
			}

			if (Images.Count > 1)
			{
				ButtonNext.Enabled = true;
			}

			//Load config
			if (File.Exists(ConfigPath))
			{
				LoadConfig(ConfigPath);

				//Set proper model
				foreach(Image ModelImage in ImageModelHash.Keys)
				{
					String CheckName = (String)ImageModelHash[ModelImage];

					if (CheckName == ModelName)
					{
						for (int i=0; i<Images.Count; i++)
						{
							if (Images[i] == ModelImage)
							{
								PictureIndex = i;
								PictureBoxModels.Image = ModelImage;

								ButtonPrevious.Enabled = false;
								ButtonNext.Enabled = false;

								if (i == 0)
								{
									ButtonNext.Enabled = false;
								}
								else if (i == (Images.Count - 1))
								{
									ButtonPrevious.Enabled = false;
								}

								if (i > 0)
								{
									ButtonPrevious.Enabled = true;
								}

								if (i < (Images.Count - 1))
								{
									ButtonNext.Enabled = true;
								}
							}
						}
					}
				}
			}
		}

		private void ButtonPrevious_Click(object sender, System.EventArgs e)
		{
			ButtonNext.Enabled = true;
			PictureIndex--;

			if (PictureIndex >= 0)
			{
				PictureBoxModels.Image = (Image)Images[PictureIndex];

				if (PictureIndex == 0)
				{
					ButtonPrevious.Enabled = false;
				}
			}
			else
			{
				
				PictureIndex = 0;
			}
		}

		private void ButtonNext_Click(object sender, System.EventArgs e)
		{
			ButtonPrevious.Enabled = true;
			PictureIndex++;

			if (PictureIndex < Images.Count)
			{
				PictureBoxModels.Image = (Image)Images[PictureIndex];

				if (PictureIndex == (Images.Count - 1))
				{
					ButtonNext.Enabled = false;
				}
			}
			else
			{
				PictureIndex = Images.Count - 1;
			}
		}

		private void ButtonOK_Click(object sender, System.EventArgs e)
		{
			try
			{
				if (CheckBoxServer.Checked)
				{
					ServerAddress = IPAddress.Parse(TextBoxServerAddress.Text);
				}
				else
				{
					ServerAddress = null;
				}

				VoiceEnabled = CheckBoxVoice.Enabled;
				ModelName = ImageModelHash[ Images[PictureIndex] ].ToString();
				ReturnProfile = new UserProfile(TextBoxName.Text, ModelName);
				SaveConfig(ConfigPath);
				this.Close();
			}
			catch(System.FormatException)
			{
				MessageBox.Show(this, "Please enter a valid IP address in the Server Address field",
					"Invalid IP address", MessageBoxButtons.OK, MessageBoxIcon.Error);
			}
		}

		private void ButtonCancel_Click(object sender, System.EventArgs e)
		{
			ReturnProfile = null;
			ServerAddress = null;
		}

		private void CheckBoxServer_CheckedChanged(object sender, System.EventArgs e)
		{
			TextBoxServerAddress.Enabled = CheckBoxServer.Checked;
		}
	}
}
