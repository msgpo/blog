using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.Threading;
using System.Net;

//WanderEngine
using WanderEngine;

//Audio & Video
using Microsoft.DirectX.AudioVideoPlayback;

namespace Final
{
	/// <summary>
	/// Summary description for FormMain.
	/// </summary>
	public class FormMain : System.Windows.Forms.Form
	{
		private Tao.Platform.Windows.SimpleOpenGlControl simpleOpenGlControlMain;
		private System.ComponentModel.IContainer components = null;
		private System.Windows.Forms.PictureBox PictureBoxAvatar;
		private System.Windows.Forms.Label LabelHealth;
		private System.Windows.Forms.Label LabelPlayerInfo;
		private System.Windows.Forms.Label LabelTime;
		private System.Windows.Forms.Label LabelWinner;

		#region WanderEngine variables

		private Engine WEngine = null;
		private bool ConnectedToServer = false;
						
		#endregion

		#region State Variables

		private bool GameCreated = true;

		#endregion		

		#region Window Variables

		private FormBanner Banner = new FormBanner();

		#endregion

		#region Config Variables

		private bool ServerEnabled = true;
		private bool VoiceEnabled = false;
		private UserProfile Profile = null;
		private IPAddress ServerAddress = null;

		#endregion

		private System.Windows.Forms.ProgressBar ProgressBarAmmo;
		private System.Windows.Forms.Label LabelWeapon;

		#region Tooltip Variables

		private Audio BuzzerSound = null;

		#endregion

		public FormMain()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(FormMain));
			this.LabelWeapon = new System.Windows.Forms.Label();
			this.ProgressBarAmmo = new System.Windows.Forms.ProgressBar();
			this.LabelWinner = new System.Windows.Forms.Label();
			this.LabelTime = new System.Windows.Forms.Label();
			this.LabelPlayerInfo = new System.Windows.Forms.Label();
			this.LabelHealth = new System.Windows.Forms.Label();
			this.PictureBoxAvatar = new System.Windows.Forms.PictureBox();
			this.simpleOpenGlControlMain = new Tao.Platform.Windows.SimpleOpenGlControl();
			this.SuspendLayout();
			// 
			// LabelWeapon
			// 
			this.LabelWeapon.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.LabelWeapon.Font = new System.Drawing.Font("Arial", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.LabelWeapon.Location = new System.Drawing.Point(240, 512);
			this.LabelWeapon.Name = "LabelWeapon";
			this.LabelWeapon.Size = new System.Drawing.Size(64, 40);
			this.LabelWeapon.TabIndex = 27;
			this.LabelWeapon.Text = "Knife";
			this.LabelWeapon.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// ProgressBarAmmo
			// 
			this.ProgressBarAmmo.Location = new System.Drawing.Point(240, 560);
			this.ProgressBarAmmo.Maximum = 20;
			this.ProgressBarAmmo.Name = "ProgressBarAmmo";
			this.ProgressBarAmmo.Size = new System.Drawing.Size(64, 16);
			this.ProgressBarAmmo.TabIndex = 26;
			this.ProgressBarAmmo.Value = 10;
			// 
			// LabelWinner
			// 
			this.LabelWinner.Dock = System.Windows.Forms.DockStyle.Top;
			this.LabelWinner.Font = new System.Drawing.Font("Arial", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.LabelWinner.Location = new System.Drawing.Point(0, 0);
			this.LabelWinner.Name = "LabelWinner";
			this.LabelWinner.Size = new System.Drawing.Size(656, 32);
			this.LabelWinner.TabIndex = 25;
			this.LabelWinner.Text = "No winners yet";
			this.LabelWinner.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// LabelTime
			// 
			this.LabelTime.Font = new System.Drawing.Font("Monotype Corsiva", 25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.LabelTime.ForeColor = System.Drawing.Color.MidnightBlue;
			this.LabelTime.Location = new System.Drawing.Point(456, 520);
			this.LabelTime.Name = "LabelTime";
			this.LabelTime.Size = new System.Drawing.Size(184, 48);
			this.LabelTime.TabIndex = 24;
			this.LabelTime.Text = "0:00 left";
			this.LabelTime.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// LabelPlayerInfo
			// 
			this.LabelPlayerInfo.Font = new System.Drawing.Font("Impact", 18F);
			this.LabelPlayerInfo.ForeColor = System.Drawing.Color.DarkGreen;
			this.LabelPlayerInfo.Location = new System.Drawing.Point(16, 512);
			this.LabelPlayerInfo.Name = "LabelPlayerInfo";
			this.LabelPlayerInfo.Size = new System.Drawing.Size(224, 64);
			this.LabelPlayerInfo.TabIndex = 23;
			this.LabelPlayerInfo.Text = "NoName: 0";
			this.LabelPlayerInfo.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// LabelHealth
			// 
			this.LabelHealth.Font = new System.Drawing.Font("Impact", 25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.LabelHealth.ForeColor = System.Drawing.Color.Red;
			this.LabelHealth.Location = new System.Drawing.Point(376, 528);
			this.LabelHealth.Name = "LabelHealth";
			this.LabelHealth.Size = new System.Drawing.Size(64, 40);
			this.LabelHealth.TabIndex = 21;
			this.LabelHealth.Text = "100";
			this.LabelHealth.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// PictureBoxAvatar
			// 
			this.PictureBoxAvatar.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.PictureBoxAvatar.Location = new System.Drawing.Point(320, 512);
			this.PictureBoxAvatar.Name = "PictureBoxAvatar";
			this.PictureBoxAvatar.Size = new System.Drawing.Size(48, 64);
			this.PictureBoxAvatar.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
			this.PictureBoxAvatar.TabIndex = 20;
			this.PictureBoxAvatar.TabStop = false;
			// 
			// simpleOpenGlControlMain
			// 
			this.simpleOpenGlControlMain.AccumBits = ((System.Byte)(0));
			this.simpleOpenGlControlMain.AutoCheckErrors = false;
			this.simpleOpenGlControlMain.AutoFinish = false;
			this.simpleOpenGlControlMain.AutoMakeCurrent = true;
			this.simpleOpenGlControlMain.AutoSwapBuffers = true;
			this.simpleOpenGlControlMain.BackColor = System.Drawing.Color.Black;
			this.simpleOpenGlControlMain.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("simpleOpenGlControlMain.BackgroundImage")));
			this.simpleOpenGlControlMain.ColorBits = ((System.Byte)(32));
			this.simpleOpenGlControlMain.DepthBits = ((System.Byte)(24));
			this.simpleOpenGlControlMain.Location = new System.Drawing.Point(8, 24);
			this.simpleOpenGlControlMain.Name = "simpleOpenGlControlMain";
			this.simpleOpenGlControlMain.Size = new System.Drawing.Size(640, 480);
			this.simpleOpenGlControlMain.StencilBits = ((System.Byte)(0));
			this.simpleOpenGlControlMain.TabIndex = 0;
			this.simpleOpenGlControlMain.Visible = false;
			// 
			// FormMain
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.BackColor = System.Drawing.Color.White;
			this.ClientSize = new System.Drawing.Size(656, 582);
			this.Controls.Add(this.PictureBoxAvatar);
			this.Controls.Add(this.LabelHealth);
			this.Controls.Add(this.LabelPlayerInfo);
			this.Controls.Add(this.LabelTime);
			this.Controls.Add(this.LabelWeapon);
			this.Controls.Add(this.ProgressBarAmmo);
			this.Controls.Add(this.LabelWinner);
			this.Controls.Add(this.simpleOpenGlControlMain);
			this.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.MaximizeBox = false;
			this.Name = "FormMain";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "Game Programming Final";
			this.Closing += new System.ComponentModel.CancelEventHandler(this.FormMain_Closing);
			this.Activated += new System.EventHandler(this.FormMain_Activated);
			this.Deactivate += new System.EventHandler(this.FormMain_Deactivate);
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			//Enable themes
			Application.EnableVisualStyles();
			Application.DoEvents();

			using (FormMain MainForm = new FormMain())
			{
				MainForm.RunGame();
			}
		}

		private void InitializeGame()
		{
			//Initialize OpenGL
			simpleOpenGlControlMain.InitializeContexts();

			using (FormCustomSignIn ProfileSelector = new FormCustomSignIn())
			{
				ProfileSelector.ShowDialog(this);
				Profile = ProfileSelector.ReturnProfile;
				ServerAddress = ProfileSelector.ServerAddress;
				VoiceEnabled = ProfileSelector.VoiceEnabled;

				ServerEnabled = (ServerAddress != null);
			}

			if (Profile != null)
			{
				//Show banner
				Banner.Show();
				Application.DoEvents();

				Banner.BannerText = "Loading media";

				//Load media
				BuzzerSound = new Audio(Application.StartupPath + @"\sounds\buzzer.wav");

				//Initialize WanderEngine
				InitializeEngine();

				//Hide banner
				Banner.Hide();
				Banner.Dispose();

				//Show main window
				this.Show();

				//Show components
				simpleOpenGlControlMain.Visible = true;

				//Set avatar
				String AvatarName = Application.StartupPath + @"\models\" + Profile.ModelName + "_i.jpg";
				PictureBoxAvatar.Image = Image.FromFile(AvatarName);

				//Set player info
				LabelPlayerInfo.Text = Profile.Name + ": 0";

				//Enable voice chat if necessary
				if (WEngine.Connected && VoiceEnabled)
				{
					//Enable voice
					//WEngine.EnableVoice();
				}
			}
		}

		private bool InitializeEngine()
		{
			bool ReturnStatus = false;

			Banner.BannerText = "Initializing WanderEngine";

			//Setup engine
			try
			{
				WEngine = new Engine(this, simpleOpenGlControlMain);

				//Load map
				Banner.BannerText = "Loading map";
				WEngine.LoadMap(Application.StartupPath + @"\maps", "Egyptian Palace.bsp");
				
				//Hook engine events
				WEngine.ConnectedToServer += new WanderEngine.Engine.ConnectedToServerHandler(WEngine_ConnectedToServer);
				WEngine.DisconnectedFromServer += new WanderEngine.Engine.DisconnectedFromServerHandler(WEngine_DisconnectedFromServer);
				WEngine.ChatMessageRecieved += new WanderEngine.Engine.ChatMessageRecievedHandler(WEngine_ChatMessageRecieved);
				WEngine.AddPlayer += new WanderEngine.Engine.AddPlayerHandler(WEngine_AddPlayer);
				WEngine.RemovePlayer += new WanderEngine.Engine.RemovePlayerHandler(WEngine_RemovePlayer);
				WEngine.TriggerActivated += new WanderEngine.Engine.TriggerActivatedHandler(WEngine_TriggerActivated);
				WEngine.HealthChanged += new EventHandler(WEngine_HealthChanged);
				WEngine.ServerTimeChanged += new EventHandler(WEngine_ServerTimeChanged);
				WEngine.ScoreChanged += new EventHandler(WEngine_ScoreChanged);
				WEngine.GameOver += new WanderEngine.Engine.GameOverHandler(WEngine_GameOver);
				WEngine.RoundInfoChanged += new EventHandler(WEngine_RoundInfoChanged);
				WEngine.AmmoChanged += new EventHandler(WEngine_AmmoChanged);
				WEngine.QuitGame += new EventHandler(WEngine_QuitGame);
				WEngine.WeaponChanged += new EventHandler(WEngine_WeaponChanged);

				//Connect to server
				if (ServerEnabled)
				{
					Banner.BannerText = "Connecting to network server";

					//Set user info
					WEngine.PlayerName = Profile.Name;
					WEngine.ModelName = Profile.ModelName;

					//Start connection
					WEngine.ConnectToServer(ServerAddress);
			
					//Wait for connection
					int StartTime = System.Environment.TickCount;

					while (!ConnectedToServer)
					{
						//Update UI
						Application.DoEvents();

						//Timeout after 10 seconds
						if ( (System.Environment.TickCount - StartTime) > 10000 )
						{
							break;
						}
					}

					if (!WEngine.Connected)
					{
						//Set state
						ServerEnabled = false;
					}
				}
				
				ReturnStatus = true;
			}
			catch(Exception ex)
			{
				MessageBox.Show(ex.InnerException.Message, ex.Message);
			}

			return(ReturnStatus);
		}

		public void RunGame()
		{
			InitializeGame();

			if (Profile != null)
			{
				MainLoop();
				DestroyGame();
			}
		}

		private void MainLoop()
		{
			//Start loop
			float TimeElapsed = 0.033f;
			DXUtil.Timer(DirectXTimer.Start);

			while(GameCreated)
			{
				//Update engine
				WEngine.UpdateFrame(TimeElapsed);

				//Update main window
				Application.DoEvents();

				//Draw frame
				simpleOpenGlControlMain.Refresh();

				//Free processing time if not enabled
				if (WEngine.IsPaused)
				{	
					Thread.Sleep(100);
				}
				else
				{				
					//Lock to 30 frames per second
					TimeElapsed = DXUtil.Timer(DirectXTimer.GetElapsedTime);

					while (TimeElapsed < 0.033f)
					{
						TimeElapsed += DXUtil.Timer(DirectXTimer.GetElapsedTime);
					}

					if (TimeElapsed > 0.033f)
					{
						TimeElapsed = 0.033f;
					}
				}
			}
		}

		private void DestroyGame()
		{
			//Hide window
			this.Hide();

			//End game
			if (WEngine != null)
			{
				WEngine.DestroyAll();
			}

			//Stop timer
			DXUtil.Timer(DirectXTimer.Stop);

			//Uninitialize OpenGL
			simpleOpenGlControlMain.DestroyContexts();

			//Destroy window
			this.Close();
		}

		#region Window Event Handlers

		private void FormMain_Closing(object sender, System.ComponentModel.CancelEventArgs e)
		{
			if (GameCreated)
			{
				e.Cancel = true;
				GameCreated = false;
			}
		}

		private void FormMain_Activated(object sender, System.EventArgs e)
		{
			if (WEngine != null)
			{
				WEngine.ReAcquireInput();
				WEngine.IsPaused = false;			
			}	
		}

		private void FormMain_Deactivate(object sender, System.EventArgs e)
		{
			if (WEngine != null)
			{
				WEngine.IsPaused = true;
			}
		}

		#endregion

		#region WanderEngine Event Handlers

		private void WEngine_DisconnectedFromServer(object sender, EventArgs e)
		{
			//Do nothing
		}

		private void WEngine_ConnectedToServer(object sender, EventArgs e)
		{
			//Set event
			ConnectedToServer = true;
		}

		private void WEngine_ChatMessageRecieved(object sender, ChatMessageEventArgs e)
		{
			/*
			//Play sound
			if (NewMessage != null)
			{
				NewMessage.CurrentPosition = 0;
				NewMessage.Play();
			}

			if (e.SenderID == WEngine.NetworkID)
			{
				WriteChatConsole(WEngine.PlayerName + ": ", SelfConsoleColor, true, false);
				WriteChatConsole(e.ChatMessage, Color.Black, false, true);
			}
			else
			{
				//Lookup player
				Player CurrentPlayer = (Player)IDPlayerHash[e.SenderID];

				if (e.IsPrivate)
				{
					WriteChatConsole("[From " + CurrentPlayer.Name + "]: ", OtherConsoleColor, true, false);
					WriteChatConsole(e.ChatMessage, Color.Black, false, true);
				}
				else
				{
					WriteChatConsole(CurrentPlayer.Name + ": ", OtherConsoleColor, true, false);
					WriteChatConsole(e.ChatMessage, Color.Black, false, true);
				}
			}
			*/
		}

		private void WEngine_AddPlayer(object sender, PlayerEventArgs e)
		{
			//AddPlayer( new Player(e.ID, e.Name) );
		}

		private void WEngine_RemovePlayer(object sender, PlayerEventArgs e)
		{
			//RemovePlayer(e.ID);
		}

		private void WEngine_TriggerActivated(object sender, TriggerEventArgs e)
		{
			//Do nothing
		}

		private void WEngine_HealthChanged(object sender, EventArgs e)
		{
			LabelHealth.Text = WEngine.Health.ToString();
			LabelHealth.Refresh();
		}

		private void WEngine_ServerTimeChanged(object sender, EventArgs e)
		{
			LabelTime.Text = (new TimeSpan(0, 0, 0, WEngine.SecondsLeft)).ToString() + " left";
			LabelTime.Refresh();
		}

		private void WEngine_ScoreChanged(object sender, EventArgs e)
		{
			LabelPlayerInfo.Text = Profile.Name + ": " + WEngine.Score.ToString();
			LabelPlayerInfo.Refresh();
		}

		private void WEngine_GameOver(object sender, GameOverEventArgs e)
		{
			//Player buzzer sound
			if (BuzzerSound != null)
			{
				BuzzerSound.CurrentPosition = 0;
				BuzzerSound.Play();
			}
			
			if (e.ID == WEngine.NetworkID)
			{
				LabelWinner.Text = "You won with a score of " + e.Score.ToString() + "!";
			}
			else
			{
				LabelWinner.Text = e.Name + " won with a score of " + e.Score.ToString() + "!";
			}

			LabelWinner.Refresh();
			
			//Restart session
			WEngine.Score = 0;
			LabelPlayerInfo.Text = Profile.Name + ": " + WEngine.Score.ToString();
			LabelPlayerInfo.Refresh();
			WEngine.Respawn();
		}

		private void WEngine_RoundInfoChanged(object sender, EventArgs e)
		{
			LabelWinner.Text = WEngine.RoundInfo;
			LabelWinner.Refresh();
		}

		private void WEngine_AmmoChanged(object sender, EventArgs e)
		{
			ProgressBarAmmo.Value = WEngine.Ammo;
		}

		private void WEngine_QuitGame(object sender, EventArgs e)
		{
			this.Close();
		}

		private void WEngine_WeaponChanged(object sender, EventArgs e)
		{
			if (WEngine.Weapon == WeaponType.Knife)
			{
				LabelWeapon.Text = "Knife";
				LabelWeapon.Refresh();
				ProgressBarAmmo.Value = ProgressBarAmmo.Maximum;
			}
			else if (WEngine.Weapon == WeaponType.Laser)
			{
				LabelWeapon.Text = "Laser";
				LabelWeapon.Refresh();
				ProgressBarAmmo.Value = WEngine.Ammo;
			}

		}

		#endregion
	}
}
