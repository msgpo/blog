using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace Final
{
	/// <summary>
	/// Summary description for FormBanner.
	/// </summary>
	public class FormBanner : System.Windows.Forms.Form
	{
		private LabelGradient.LabelGradient LabelGradientLoading;
		private System.Windows.Forms.Label LabelTitle;
		private System.ComponentModel.IContainer components = null;

		private delegate void StringDelegate(String S);

		public String BannerText
		{
			get { return(LabelGradientLoading.Text); }
			set { SetBannerText(value); }
		}

		public FormBanner()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();
		}

		private void SetBannerText(String NewText)
		{
			this.Invoke( new StringDelegate(SetBannerText_Safe),
				new object[] { NewText } );
		}

		private void SetBannerText_Safe(String NewText)
		{
			LabelGradientLoading.Text = NewText;
			LabelGradientLoading.Refresh();
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(FormBanner));
			this.LabelGradientLoading = new LabelGradient.LabelGradient();
			this.LabelTitle = new System.Windows.Forms.Label();
			this.SuspendLayout();
			// 
			// LabelGradientLoading
			// 
			this.LabelGradientLoading.BorderStyle = System.Windows.Forms.Border3DStyle.Adjust;
			this.LabelGradientLoading.Dock = System.Windows.Forms.DockStyle.Bottom;
			this.LabelGradientLoading.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.LabelGradientLoading.ForeColor = System.Drawing.Color.White;
			this.LabelGradientLoading.GradientColorOne = System.Drawing.Color.SteelBlue;
			this.LabelGradientLoading.GradientColorTwo = System.Drawing.Color.CornflowerBlue;
			this.LabelGradientLoading.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.Vertical;
			this.LabelGradientLoading.Location = new System.Drawing.Point(0, 72);
			this.LabelGradientLoading.Name = "LabelGradientLoading";
			this.LabelGradientLoading.Size = new System.Drawing.Size(472, 40);
			this.LabelGradientLoading.TabIndex = 6;
			this.LabelGradientLoading.Text = "Loading";
			this.LabelGradientLoading.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// LabelTitle
			// 
			this.LabelTitle.Dock = System.Windows.Forms.DockStyle.Fill;
			this.LabelTitle.Font = new System.Drawing.Font("Lucida Sans", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.LabelTitle.ForeColor = System.Drawing.Color.RoyalBlue;
			this.LabelTitle.Location = new System.Drawing.Point(0, 0);
			this.LabelTitle.Name = "LabelTitle";
			this.LabelTitle.Size = new System.Drawing.Size(472, 72);
			this.LabelTitle.TabIndex = 7;
			this.LabelTitle.Text = "Game Programming Final";
			this.LabelTitle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// FormBanner
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.BackColor = System.Drawing.Color.White;
			this.ClientSize = new System.Drawing.Size(472, 112);
			this.ControlBox = false;
			this.Controls.Add(this.LabelTitle);
			this.Controls.Add(this.LabelGradientLoading);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.Name = "FormBanner";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "Starting up";
			this.ResumeLayout(false);

		}
		#endregion
	}
}
