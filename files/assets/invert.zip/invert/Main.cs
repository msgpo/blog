// Copyright (c) 2011 Michael Hansen (mihansen@indiana.edu)
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to
// deal in the Software without restriction, including without limitation the
// rights to use, copy, modify, merge, publish, distribute, sublicense, and/or
// sell copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in
// all copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
// FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
// IN THE SOFTWARE.

using System;
using System.IO;
using System.Drawing;
using NDesk.Options;

namespace Invert {

  class PointD {
    public double X { get; set; }
    public double Y { get; set; }

    public PointD(double x, double y) {
      X = x;
      Y = y;
    }
  }

  class Program {

    static PointD invert(PointD old, PointD center, double radius) {
      var dist = Math.Pow((old.X - center.X), 2) + Math.Pow((old.Y - center.Y), 2);
      var rSquared = Math.Pow(radius, 2);

      return new PointD((rSquared * (old.X - center.X)) / dist,
                        (rSquared * (old.Y - center.Y)) / dist);
    }

    static void Main(string[] args) {

      double imageScale = 1.0;
      double? radius = null;
      bool showHelp = false, tile = false;
      Color infinityColor = Color.White;
      double? centerX = null, centerY = null;
      string outputFile = null;

      var options = new OptionSet()
      {
        { "h|?|help", "Show this help message",
          v => showHelp = !string.IsNullOrEmpty(v) },

        { "tile", "Tile source image across the plane (default: no)",
          v => tile = !string.IsNullOrEmpty(v) },
          
        { "radius=", "Radius of the inversion circle (default: half image width)",
          v => radius = Convert.ToDouble(v) },
          
        { "center-x=", "X coordinate of inversion circle center (default: half image width)",
          v => centerX = Convert.ToDouble(v) },
          
        { "center-y=", "Y coordinate of inversion circle center (default: half image height)",
          v => centerY = Convert.ToDouble(v) },
          
        { "image-scale=", "Scalar for inverted image size (default: 1.0)",
          v => imageScale = Convert.ToDouble(v) },
          
        { "infinity-color=", "Color to use for points beyond image bounds in non-tiled case (default: #FFFFFFFF)",
          v => infinityColor = ColorTranslator.FromHtml(v) },

        { "output-file=", "Output file name (default: append .inverted to source file name)",
          v => outputFile = v },
      };

      var extraOptions = options.Parse(args);
      
      if (showHelp)
      {
        options.WriteOptionDescriptions(Console.Out);
        return;
      }

      if (extraOptions.Count < 1) {
        Console.WriteLine("Missing input file");
        return;
      }

      string inputFile = extraOptions[0];

      var originalImage = new Bitmap(inputFile);
      var invertedImage = new Bitmap((int)Math.Round(originalImage.Width * imageScale),
                                     (int)Math.Round(originalImage.Height * imageScale));

      var halfWidth = (double)invertedImage.Width / 2.0;
      var halfHeight = (double)invertedImage.Height / 2.0;

      var circleCenter = new PointD(centerX.HasValue ? centerX.Value : halfWidth,
                                    centerY.HasValue ? centerY.Value : halfHeight);
      var circleRadius = radius.HasValue ? radius.Value : halfWidth;

      for (int x = 0; x < invertedImage.Width; ++x) {
        for (int y = 0; y < invertedImage.Height; ++y) {

          var originalPoint = invert(new PointD(x, y), circleCenter, circleRadius);

          // Origin is at image center
          var originalX = originalPoint.X + halfWidth;
          var originalY = originalPoint.Y + halfHeight;

          if (tile) {
            originalX = (int)Math.Round(Math.Abs(originalX)) % originalImage.Width;
            originalY = (int)Math.Round(Math.Abs(originalY)) % originalImage.Height;
          }
          else {
            originalX = Math.Round(originalX);
            originalY = Math.Round(originalY);
          }

          var originalColor = infinityColor;

          if ((0 <= (int)originalX) && ((int)originalX < originalImage.Width) &&
              (0 <= (int)originalY) && ((int)originalY < originalImage.Height)) {
            originalColor = originalImage.GetPixel((int)originalX, (int)originalY);
          }

          invertedImage.SetPixel(x, y, originalColor);
        }
      }

      if (string.IsNullOrEmpty(outputFile)) {
        outputFile = Path.ChangeExtension(inputFile, string.Format(".inverted{0}", Path.GetExtension(inputFile)));
      }

      invertedImage.Save(outputFile, originalImage.RawFormat);
    }
  }
}

